# Mi Día Android

App Android personal para organizar tareas, eventos y recordatorios.

## v0.2.0

- Tareas, eventos y recordatorios siguen siendo tipos distintos.
- Las tareas pueden tener fecha para hacerlas, fecha límite, hora y duración.
- Tareas sin fecha en su propia bandeja.
- Franjas libres calculadas según eventos y tareas programadas.
- Las franjas libres se pueden editar manualmente y restablecer al cálculo automático.
- Las tareas se pueden mantener presionadas desde el asa de arrastre y soltar sobre una franja libre.
- Se mantiene la alternativa de “Mover a franja libre” en el menú de tres puntos.
- Nueva sección **Hechas** con tareas completadas, eventos realizados y recordatorios atendidos.
- El calendario muestra el número y la abreviatura del día de la semana en cada celda.
- Recordatorios y alarmas locales con AlarmManager.
- Persistencia local sin cuenta ni servidor.

## Compilación

El workflow de GitHub Actions genera un APK debug y lo publica como artifact `MiDia-debug-apk`.
