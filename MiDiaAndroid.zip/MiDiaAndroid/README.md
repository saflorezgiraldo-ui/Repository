# Mi Día — Android

Prototipo Android nativo de agenda personal para tareas, eventos y recordatorios.

## Incluye

- Pantalla **Hoy**.
- Eventos por horario.
- Tareas en lista independiente.
- Fecha para hacer una tarea y fecha límite separadas.
- Tareas sin fecha en **Sin fecha**.
- Cálculo de franjas libres entre 07:00 y 22:00.
- Añadir o mover tareas a una franja libre sin convertirlas en eventos.
- Recordatorios como elemento independiente.
- Menú de tres puntos para editar, mover, completar y eliminar.
- Repetición cada X minutos, horas, días, semanas, meses o años.
- Múltiples avisos para tareas y eventos.
- Snooze de recordatorios.
- Notificaciones Android mediante AlarmManager.
- Solicitud de permiso de notificaciones y acceso a alarmas exactas.
- Persistencia local en el teléfono con SharedPreferences/JSON.
- Vistas Próximos, Calendario, Sin fecha y Ajustes.

## Probar

### Android Studio
1. Abre esta carpeta como proyecto.
2. Espera la sincronización de Gradle.
3. Conecta un Android o usa un emulador.
4. Ejecuta `app`.

### GitHub Actions
El proyecto incluye `.github/workflows/android.yml`. Al subirlo a un repositorio GitHub, el workflow compila un APK de depuración y lo deja como artifact `MiDia-debug-apk`.

## Notificaciones

En Android 13+ hay que permitir notificaciones. En Android 12+ la app ofrece abrir el permiso especial de alarmas exactas para obtener mayor precisión. Si ese permiso no está activo, usa la modalidad de alarma que Android permite.

Android puede retrasar alarmas extremadamente frecuentes por políticas de batería. Intervalos de pocos minutos no siempre son garantizados por el sistema operativo.
