# Mi Día Android — v0.3

Aplicación Android personal para organizar tareas, eventos y recordatorios.

## Novedades v0.3

- Se eliminan las franjas libres interactivas.
- Estadística diaria de tiempo libre/ocupado según tareas con hora, eventos y recordatorios.
- Recordatorios/avisos múltiples y personalizados en tareas, eventos y recordatorios.
- Subtareas dentro de las tareas.
- Prioridad: baja, media, alta y urgente.
- Filtros de tareas por prioridad.
- Selectores de fecha y hora con accesos rápidos (Hoy, Mañana, +1 semana, Ahora, 09:00, 12:00, 18:00).
- Día seleccionado resaltado en el calendario y nombre del día visible.
- Selector de tipo al añadir con estado seleccionado visible.
- Barra inferior simplificada a cinco secciones con etiquetas cortas; Ajustes pasa al icono superior.
- Modo Sistema / Día / Noche.
- Cinco colores de interfaz: verde, azul, morado, naranja y rosa.
- Sección de completadas.
- Persistencia local y notificaciones Android mediante AlarmManager.

## Créditos

- Idea y dirección: Samuel Flórez
- Diseño y decisiones de producto: Samuel Flórez
- Desarrollo colaborativo: Samuel Flórez + ChatGPT (OpenAI)

## Compilación

El workflow de GitHub Actions genera un APK debug para probar en Android.
