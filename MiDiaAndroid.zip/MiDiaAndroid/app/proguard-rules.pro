# Mi Día - no custom ProGuard rules for the first prototype.
