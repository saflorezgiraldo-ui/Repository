package com.midia.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.math.absoluteValue

object NotificationScheduler {
    const val CHANNEL_ID = "midia_reminders"
    private const val PREFS = "midia_alarm_codes"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Recordatorios de Mi Día",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Avisos de tareas, eventos y recordatorios"
                enableVibration(true)
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun showTest(context: Context) {
        createChannel(context)
        showNotification(context, "Mi Día", "Las notificaciones están funcionando.", "test".hashCode().absoluteValue)
    }

    fun canExact(context: Context): Boolean {
        val alarm = context.getSystemService(AlarmManager::class.java)
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarm.canScheduleExactAlarms()
    }

    fun exactAlarmSettingsIntent(context: Context): Intent? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || canExact(context)) return null
        return Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
            data = android.net.Uri.parse("package:${context.packageName}")
        }
    }

    fun rescheduleAll(context: Context, state: AppState) {
        createChannel(context)
        cancelPreviouslyScheduled(context)
        val codes = mutableSetOf<Int>()
        val now = System.currentTimeMillis()

        state.tasks.filterNot { it.completed }.forEach { task ->
            val base = taskDateTime(task)?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli() ?: return@forEach
            val alertOffsets = if (task.alerts.isEmpty()) emptyList() else task.alerts
            alertOffsets.forEachIndexed { idx, offset ->
                val trigger = base - offset * 60_000L
                if (trigger > now) {
                    codes += schedule(
                        context = context,
                        key = "task:${task.id}:$idx",
                        title = "Tarea: ${task.title}",
                        body = task.dueDate?.let { "Fecha límite: $it" } ?: "Tienes una tarea pendiente",
                        triggerMillis = trigger,
                        rule = task.repeat,
                        repeatUntilDone = false
                    )
                }
            }
        }

        state.events.filterNot { it.done }.forEach { event ->
            val base = eventDateTime(event)?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli() ?: return@forEach
            event.alerts.forEachIndexed { idx, offset ->
                val trigger = base - offset * 60_000L
                if (trigger > now) {
                    codes += schedule(
                        context = context,
                        key = "event:${event.id}:$idx",
                        title = "Evento: ${event.title}",
                        body = "Empieza a las ${event.startTime}",
                        triggerMillis = trigger,
                        rule = event.repeat,
                        repeatUntilDone = false
                    )
                }
            }
        }

        state.reminders.filterNot { it.done }.forEach { reminder ->
            val normal = reminderDateTime(reminder)?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli() ?: return@forEach
            val trigger = reminder.snoozedUntilMillis ?: normal
            if (trigger > now) {
                codes += schedule(
                    context = context,
                    key = "reminder:${reminder.id}",
                    title = reminder.title,
                    body = reminder.notes.ifBlank { "Recordatorio" },
                    triggerMillis = trigger,
                    rule = reminder.repeat,
                    repeatUntilDone = reminder.repeatUntilDone
                )
            }
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet("codes", codes.map(Int::toString).toSet()).apply()
    }

    private fun schedule(
        context: Context,
        key: String,
        title: String,
        body: String,
        triggerMillis: Long,
        rule: RepeatRule,
        repeatUntilDone: Boolean,
        requestCodeOverride: Int? = null
    ): Int {
        val requestCode = requestCodeOverride ?: key.hashCode().absoluteValue
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra("title", title)
            putExtra("body", body)
            putExtra("code", requestCode)
            putExtra("repeatUnit", rule.unit.name)
            putExtra("repeatInterval", rule.interval)
            putExtra("repeatUntilDone", repeatUntilDone)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = context.getSystemService(AlarmManager::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) {
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
            } else {
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
            }
        } catch (_: SecurityException) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
        }
        return requestCode
    }

    private fun cancelPreviouslyScheduled(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val codes = prefs.getStringSet("codes", emptySet()).orEmpty().mapNotNull { it.toIntOrNull() }
        val alarm = context.getSystemService(AlarmManager::class.java)
        codes.forEach { code ->
            val pi = PendingIntent.getBroadcast(
                context,
                code,
                Intent(context, NotificationReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) alarm.cancel(pi)
        }
        prefs.edit().remove("codes").apply()
    }

    fun scheduleNextFromReceiver(context: Context, originalIntent: Intent) {
        val unit = runCatching { RepeatUnit.valueOf(originalIntent.getStringExtra("repeatUnit") ?: "NONE") }.getOrDefault(RepeatUnit.NONE)
        val interval = originalIntent.getIntExtra("repeatInterval", 1).coerceAtLeast(1)
        val repeatUntilDone = originalIntent.getBooleanExtra("repeatUntilDone", false)
        val next = nextOccurrence(System.currentTimeMillis(), RepeatRule(unit, interval), repeatUntilDone) ?: return
        schedule(
            context,
            "receiver:${originalIntent.getIntExtra("code", 0)}",
            originalIntent.getStringExtra("title") ?: "Mi Día",
            originalIntent.getStringExtra("body") ?: "Recordatorio",
            next,
            RepeatRule(unit, interval),
            repeatUntilDone,
            requestCodeOverride = originalIntent.getIntExtra("code", 0)
        )
    }

    private fun showNotification(context: Context, title: String, body: String, id: Int) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val openApp = PendingIntent.getActivity(
            context,
            id,
            Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
        NotificationManagerCompat.from(context).notify(id, notification)
    }

    fun deliver(context: Context, intent: Intent) {
        createChannel(context)
        showNotification(
            context,
            intent.getStringExtra("title") ?: "Mi Día",
            intent.getStringExtra("body") ?: "Recordatorio",
            intent.getIntExtra("code", System.currentTimeMillis().toInt().absoluteValue)
        )
        scheduleNextFromReceiver(context, intent)
    }
}

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        NotificationScheduler.deliver(context, intent)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val store = AppStore(context.applicationContext)
            NotificationScheduler.rescheduleAll(context, store.state)
        }
    }
}
