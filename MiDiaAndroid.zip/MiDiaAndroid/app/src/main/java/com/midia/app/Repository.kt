package com.midia.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

class AppStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("midia_state", Context.MODE_PRIVATE)
    var state by mutableStateOf(load())
        private set

    fun update(transform: (AppState) -> AppState) {
        state = transform(state)
        save(state)
        NotificationScheduler.rescheduleAll(context, state)
    }

    fun addTask(item: TaskItem) = update { it.copy(tasks = it.tasks + item) }
    fun addEvent(item: EventItem) = update { it.copy(events = it.events + item) }
    fun addReminder(item: ReminderItem) = update { it.copy(reminders = it.reminders + item) }

    fun replaceTask(item: TaskItem) = update { s -> s.copy(tasks = s.tasks.map { if (it.id == item.id) item else it }) }
    fun replaceEvent(item: EventItem) = update { s -> s.copy(events = s.events.map { if (it.id == item.id) item else it }) }
    fun replaceReminder(item: ReminderItem) = update { s -> s.copy(reminders = s.reminders.map { if (it.id == item.id) item else it }) }

    fun deleteTask(id: String) = update { it.copy(tasks = it.tasks.filterNot { x -> x.id == id }) }
    fun deleteEvent(id: String) = update { it.copy(events = it.events.filterNot { x -> x.id == id }) }
    fun deleteReminder(id: String) = update { it.copy(reminders = it.reminders.filterNot { x -> x.id == id }) }

    fun setFreeSlotsForDate(date: String, slots: List<TimeSlot>) = update { current ->
        val kept = current.freeSlotOverrides.filterNot { it.date == date }
        val manual = slots.filter { it.endMinutes - it.startMinutes >= 15 }.map {
            FreeSlotOverride(date = date, startMinutes = it.startMinutes, endMinutes = it.endMinutes)
        }
        current.copy(freeSlotOverrides = kept + manual)
    }

    fun resetFreeSlotsForDate(date: String) = update { current ->
        current.copy(freeSlotOverrides = current.freeSlotOverrides.filterNot { it.date == date })
    }

    fun clearAll() = update { AppState() }

    private fun save(s: AppState) {
        val root = JSONObject()
        root.put("tasks", JSONArray().apply { s.tasks.forEach { put(taskToJson(it)) } })
        root.put("events", JSONArray().apply { s.events.forEach { put(eventToJson(it)) } })
        root.put("reminders", JSONArray().apply { s.reminders.forEach { put(reminderToJson(it)) } })
        root.put("freeSlotOverrides", JSONArray().apply { s.freeSlotOverrides.forEach { put(freeSlotToJson(it)) } })
        prefs.edit().putString("state", root.toString()).apply()
    }

    private fun load(): AppState {
        val raw = prefs.getString("state", null) ?: return demoState()
        return runCatching {
            val root = JSONObject(raw)
            AppState(
                tasks = root.optJSONArray("tasks").mapObjects(::taskFromJson),
                events = root.optJSONArray("events").mapObjects(::eventFromJson),
                reminders = root.optJSONArray("reminders").mapObjects(::reminderFromJson),
                freeSlotOverrides = root.optJSONArray("freeSlotOverrides").mapObjects(::freeSlotFromJson)
            )
        }.getOrElse { AppState() }
    }

    private fun demoState(): AppState {
        val today = java.time.LocalDate.now().toString()
        val yesterday = java.time.LocalDate.now().minusDays(1).toString()
        return AppState(
            tasks = listOf(
                TaskItem(title = "Terminar presentación", category = "Universidad", doDate = today, dueDate = today, alerts = listOf(60)),
                TaskItem(title = "Organizar archivos pendientes", category = "Personal", doDate = yesterday),
                TaskItem(title = "Comprar algo para la casa", category = "Personal", doDate = null)
            ),
            events = listOf(
                EventItem(title = "Clase", date = today, startTime = "08:00", endTime = "10:00", location = "Universidad"),
                EventItem(title = "Almuerzo", date = today, startTime = "13:00", endTime = "14:00")
            ),
            reminders = listOf(
                ReminderItem(title = "Revisar pendientes", date = today, time = "19:00", repeatUntilDone = true)
            )
        )
    }
}

private inline fun <reified T> JSONArray?.mapObjects(parser: (JSONObject) -> T): List<T> {
    if (this == null) return emptyList()
    return buildList { for (i in 0 until length()) add(parser(getJSONObject(i))) }
}

private fun JSONArray?.toTaskList() = mapObjects(::taskFromJson)
private fun JSONArray?.toEventList() = mapObjects(::eventFromJson)
private fun JSONArray?.toReminderList() = mapObjects(::reminderFromJson)

private fun repeatToJson(r: RepeatRule) = JSONObject().put("unit", r.unit.name).put("interval", r.interval)
private fun repeatFromJson(o: JSONObject?) = RepeatRule(
    unit = runCatching { RepeatUnit.valueOf(o?.optString("unit") ?: "NONE") }.getOrDefault(RepeatUnit.NONE),
    interval = (o?.optInt("interval", 1) ?: 1).coerceAtLeast(1)
)
private fun alertsToJson(list: List<Int>) = JSONArray().apply { list.forEach { put(it) } }
private fun alertsFromJson(a: JSONArray?): List<Int> = if (a == null) emptyList() else buildList { for (i in 0 until a.length()) add(a.optInt(i)) }

private fun taskToJson(t: TaskItem) = JSONObject().apply {
    put("id", t.id); put("title", t.title); put("notes", t.notes); put("category", t.category)
    put("doDate", t.doDate); put("dueDate", t.dueDate); put("startTime", t.startTime); put("duration", t.durationMinutes)
    put("completed", t.completed); put("repeat", repeatToJson(t.repeat)); put("alerts", alertsToJson(t.alerts))
}
private fun taskFromJson(o: JSONObject) = TaskItem(
    id = o.optString("id"), title = o.optString("title"), notes = o.optString("notes"), category = o.optString("category"),
    doDate = o.optNullableString("doDate"), dueDate = o.optNullableString("dueDate"), startTime = o.optNullableString("startTime"),
    durationMinutes = if (o.isNull("duration")) null else o.optInt("duration"), completed = o.optBoolean("completed"),
    repeat = repeatFromJson(o.optJSONObject("repeat")), alerts = alertsFromJson(o.optJSONArray("alerts"))
)

private fun eventToJson(e: EventItem) = JSONObject().apply {
    put("id", e.id); put("title", e.title); put("date", e.date); put("startTime", e.startTime); put("endTime", e.endTime)
    put("notes", e.notes); put("location", e.location); put("done", e.done); put("repeat", repeatToJson(e.repeat)); put("alerts", alertsToJson(e.alerts))
}
private fun eventFromJson(o: JSONObject) = EventItem(
    id = o.optString("id"), title = o.optString("title"), date = o.optString("date"), startTime = o.optString("startTime"), endTime = o.optString("endTime"),
    notes = o.optString("notes"), location = o.optString("location"), done = o.optBoolean("done"),
    repeat = repeatFromJson(o.optJSONObject("repeat")), alerts = alertsFromJson(o.optJSONArray("alerts"))
)

private fun reminderToJson(r: ReminderItem) = JSONObject().apply {
    put("id", r.id); put("title", r.title); put("date", r.date); put("time", r.time); put("notes", r.notes); put("done", r.done)
    put("repeat", repeatToJson(r.repeat)); put("repeatUntilDone", r.repeatUntilDone); put("snoozedUntil", r.snoozedUntilMillis)
}
private fun reminderFromJson(o: JSONObject) = ReminderItem(
    id = o.optString("id"), title = o.optString("title"), date = o.optString("date"), time = o.optString("time"), notes = o.optString("notes"),
    done = o.optBoolean("done"), repeat = repeatFromJson(o.optJSONObject("repeat")), repeatUntilDone = o.optBoolean("repeatUntilDone"),
    snoozedUntilMillis = if (o.isNull("snoozedUntil")) null else o.optLong("snoozedUntil")
)

private fun freeSlotToJson(slot: FreeSlotOverride) = JSONObject().apply {
    put("id", slot.id); put("date", slot.date); put("startMinutes", slot.startMinutes); put("endMinutes", slot.endMinutes)
}
private fun freeSlotFromJson(o: JSONObject) = FreeSlotOverride(
    id = o.optString("id"), date = o.optString("date"), startMinutes = o.optInt("startMinutes"), endMinutes = o.optInt("endMinutes")
)

private fun JSONObject.optNullableString(key: String): String? = if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
