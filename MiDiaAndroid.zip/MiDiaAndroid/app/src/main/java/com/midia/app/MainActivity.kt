package com.midia.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationScheduler.createChannel(this)
        setContent { MiDiaApp() }
    }
}

enum class AppTab(val shortLabel: String, val title: String) {
    TODAY("Hoy", "Mi Día"),
    UPCOMING("Próx.", "Próximos"),
    CALENDAR("Calend.", "Calendario"),
    INBOX("Sin fecha", "Sin fecha"),
    COMPLETED("Hechas", "Completadas")
}

enum class NewType { TASK, EVENT, REMINDER }

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun MiDiaApp() {
    val context = LocalContext.current
    val store = remember { AppStore(context.applicationContext) }
    var tab by remember { mutableStateOf(AppTab.TODAY) }
    var settingsOpen by remember { mutableStateOf(false) }
    var chooser by remember { mutableStateOf(false) }
    var taskEdit by remember { mutableStateOf<TaskItem?>(null) }
    var taskDialogOpen by remember { mutableStateOf(false) }
    var eventEdit by remember { mutableStateOf<EventItem?>(null) }
    var eventDialogOpen by remember { mutableStateOf(false) }
    var reminderEdit by remember { mutableStateOf<ReminderItem?>(null) }
    var reminderDialogOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { NotificationScheduler.rescheduleAll(context, store.state) }

    val systemDark = isSystemInDarkTheme()
    val dark = when (store.state.settings.themeMode) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val scheme = remember(dark, store.state.settings.accentColor) {
        appColorScheme(dark, store.state.settings.accentColor)
    }

    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (settingsOpen) "Ajustes" else tab.title) },
                    navigationIcon = {
                        if (settingsOpen) IconButton(onClick = { settingsOpen = false }) {
                            Icon(Icons.Default.ArrowBack, "Volver")
                        }
                    },
                    actions = {
                        if (!settingsOpen) IconButton(onClick = { settingsOpen = true }) {
                            Icon(Icons.Default.Settings, "Ajustes")
                        }
                    }
                )
            },
            floatingActionButton = {
                if (!settingsOpen) FloatingActionButton(onClick = { chooser = true }) {
                    Icon(Icons.Default.Add, "Añadir")
                }
            },
            bottomBar = {
                if (!settingsOpen) {
                    NavigationBar {
                        val icons = mapOf(
                            AppTab.TODAY to Icons.Default.Today,
                            AppTab.UPCOMING to Icons.Default.DateRange,
                            AppTab.CALENDAR to Icons.Default.CalendarMonth,
                            AppTab.INBOX to Icons.Default.Inbox,
                            AppTab.COMPLETED to Icons.Default.DoneAll
                        )
                        AppTab.entries.forEach { item ->
                            NavigationBarItem(
                                selected = tab == item,
                                onClick = { tab = item },
                                icon = { Icon(icons.getValue(item), item.title) },
                                label = {
                                    Text(
                                        item.shortLabel,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        fontWeight = if (tab == item) FontWeight.SemiBold else FontWeight.Normal
                                    )
                                },
                                alwaysShowLabel = true
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                if (settingsOpen) {
                    SettingsScreen(store)
                } else {
                    when (tab) {
                        AppTab.TODAY -> TodayScreen(
                            state = store.state,
                            onEditTask = { taskEdit = it; taskDialogOpen = true },
                            onEditEvent = { eventEdit = it; eventDialogOpen = true },
                            onEditReminder = { reminderEdit = it; reminderDialogOpen = true },
                            onTaskUpdate = store::replaceTask,
                            onEventUpdate = store::replaceEvent,
                            onReminderUpdate = store::replaceReminder,
                            onDeleteTask = store::deleteTask,
                            onDeleteEvent = store::deleteEvent,
                            onDeleteReminder = store::deleteReminder
                        )
                        AppTab.UPCOMING -> UpcomingScreen(
                            store.state,
                            store::replaceTask,
                            { taskEdit = it; taskDialogOpen = true },
                            { eventEdit = it; eventDialogOpen = true },
                            { reminderEdit = it; reminderDialogOpen = true }
                        )
                        AppTab.CALENDAR -> CalendarScreen(
                            store.state,
                            store::replaceTask,
                            { taskEdit = it; taskDialogOpen = true },
                            { eventEdit = it; eventDialogOpen = true },
                            { reminderEdit = it; reminderDialogOpen = true }
                        )
                        AppTab.INBOX -> InboxScreen(
                            store.state,
                            store::replaceTask,
                            { taskEdit = it; taskDialogOpen = true },
                            store::deleteTask
                        )
                        AppTab.COMPLETED -> CompletedScreen(
                            store.state,
                            store::replaceTask,
                            store::replaceEvent,
                            store::replaceReminder,
                            { taskEdit = it; taskDialogOpen = true },
                            { eventEdit = it; eventDialogOpen = true },
                            { reminderEdit = it; reminderDialogOpen = true },
                            store::deleteTask,
                            store::deleteEvent,
                            store::deleteReminder
                        )
                    }
                }
            }
        }

        if (chooser) TypeChooser(onDismiss = { chooser = false }) { type ->
            chooser = false
            when (type) {
                NewType.TASK -> { taskEdit = null; taskDialogOpen = true }
                NewType.EVENT -> { eventEdit = null; eventDialogOpen = true }
                NewType.REMINDER -> { reminderEdit = null; reminderDialogOpen = true }
            }
        }

        if (taskDialogOpen) TaskEditDialog(
            existing = taskEdit,
            onDismiss = { taskDialogOpen = false; taskEdit = null },
            onSave = { item ->
                if (store.state.tasks.any { it.id == item.id }) store.replaceTask(item) else store.addTask(item)
                taskDialogOpen = false
                taskEdit = null
            }
        )
        if (eventDialogOpen) EventEditDialog(
            existing = eventEdit,
            onDismiss = { eventDialogOpen = false; eventEdit = null },
            onSave = { item ->
                if (store.state.events.any { it.id == item.id }) store.replaceEvent(item) else store.addEvent(item)
                eventDialogOpen = false
                eventEdit = null
            }
        )
        if (reminderDialogOpen) ReminderEditDialog(
            existing = reminderEdit,
            onDismiss = { reminderDialogOpen = false; reminderEdit = null },
            onSave = { item ->
                if (store.state.reminders.any { it.id == item.id }) store.replaceReminder(item) else store.addReminder(item)
                reminderDialogOpen = false
                reminderEdit = null
            }
        )
    }
}

private fun appColorScheme(dark: Boolean, accent: AccentColor): ColorScheme {
    val primary = when (accent) {
        AccentColor.GREEN -> if (dark) Color(0xFF8ED4C3) else Color(0xFF386A5F)
        AccentColor.BLUE -> if (dark) Color(0xFFAEC7FF) else Color(0xFF3D63A8)
        AccentColor.PURPLE -> if (dark) Color(0xFFD0BCFF) else Color(0xFF6A55A4)
        AccentColor.ORANGE -> if (dark) Color(0xFFFFB77A) else Color(0xFF9A5D22)
        AccentColor.ROSE -> if (dark) Color(0xFFFFB0C8) else Color(0xFF9A4D65)
    }
    return if (dark) darkColorScheme(primary = primary, secondary = primary) else lightColorScheme(primary = primary, secondary = primary)
}

@Composable
private fun TodayScreen(
    state: AppState,
    onEditTask: (TaskItem) -> Unit,
    onEditEvent: (EventItem) -> Unit,
    onEditReminder: (ReminderItem) -> Unit,
    onTaskUpdate: (TaskItem) -> Unit,
    onEventUpdate: (EventItem) -> Unit,
    onReminderUpdate: (ReminderItem) -> Unit,
    onDeleteTask: (String) -> Unit,
    onDeleteEvent: (String) -> Unit,
    onDeleteReminder: (String) -> Unit
) {
    val today = LocalDate.now()
    var filter by remember { mutableStateOf<Priority?>(null) }
    val allTasks = state.tasks.filter { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, today) }
    val tasks = allTasks.filter { filter == null || it.priority == filter }
    val events = state.events.filter { !it.done && occursOn(it.date, it.repeat, today) }.sortedBy { it.startTime }
    val reminders = state.reminders.filter { !it.done && occursOn(it.date, it.repeat, today) }.sortedBy { it.time }
    val overdue = state.tasks.filter {
        !it.completed && it.doDate != null && runCatching { LocalDate.parse(it.doDate) }.getOrNull()?.isBefore(today) == true && it.repeat.unit == RepeatUnit.NONE
    }.filter { filter == null || it.priority == filter }
    val stats = dayTimeStats(state, today)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                today.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale("es", "CO"))).replaceFirstChar { it.uppercase() },
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryPill("${allTasks.size} tareas")
                SummaryPill("${events.size} eventos")
                SummaryPill("${reminders.size} avisos")
            }
        }

        item { DayStatsCard(stats) }

        item { SectionTitle("Eventos") }
        if (events.isEmpty()) item { EmptyCard("No tienes eventos hoy.") }
        items(events, key = { "event-${it.id}" }) { event ->
            EventCard(event, onEditEvent, onEventUpdate, onDeleteEvent)
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionTitle("Tareas")
                PriorityFilter(filter) { filter = it }
            }
        }
        if (tasks.isEmpty()) item { EmptyCard(if (allTasks.isEmpty()) "No tienes tareas para hoy." else "No hay tareas con este filtro.") }
        items(tasks, key = { "task-${it.id}" }) { task ->
            TaskCard(task, onEditTask, onTaskUpdate, onDeleteTask)
        }

        item { SectionTitle("Recordatorios") }
        if (reminders.isEmpty()) item { EmptyCard("No tienes recordatorios hoy.") }
        items(reminders, key = { "rem-${it.id}" }) { reminder ->
            ReminderCard(reminder, onEditReminder, onReminderUpdate, onDeleteReminder)
        }

        if (overdue.isNotEmpty()) {
            item { SectionTitle("Pendientes anteriores") }
            items(overdue, key = { "overdue-${it.id}" }) { task ->
                TaskCard(task, onEditTask, onTaskUpdate, onDeleteTask)
            }
        }
    }
}

@Composable
private fun DayStatsCard(stats: DayTimeStats) {
    val occupied = (stats.busyMinutes / 1440f).coerceIn(0f, 1f)
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Tiempo libre estimado", style = MaterialTheme.typography.labelLarge)
                    Text(formatDuration(stats.freeMinutes), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Default.QueryStats, "Estadística del día", tint = MaterialTheme.colorScheme.primary)
            }
            LinearProgressIndicator(progress = { occupied }, modifier = Modifier.fillMaxWidth())
            Text("Ocupado: ${formatDuration(stats.busyMinutes)}", style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatMini("Eventos", formatDuration(stats.eventMinutes), Modifier.weight(1f))
                StatMini("Tareas", formatDuration(stats.taskMinutes), Modifier.weight(1f))
                StatMini("Avisos", stats.reminderCount.toString(), Modifier.weight(1f))
            }
            Text("Las tareas sin hora no descuentan tiempo hasta que les asignes una hora y duración.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StatMini(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(12.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(10.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun PriorityFilter(selected: Priority?, onSelected: (Priority?) -> Unit) {
    val options = listOf<Priority?>(null, Priority.URGENT, Priority.HIGH, Priority.MEDIUM, Priority.LOW)
    val labels = mapOf(
        null to "Todas",
        Priority.URGENT to "Urgente",
        Priority.HIGH to "Alta",
        Priority.MEDIUM to "Media",
        Priority.LOW to "Baja"
    )
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        options.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { p ->
                    FilterChip(selected = selected == p, onClick = { onSelected(p) }, label = { Text(labels.getValue(p)) })
                }
            }
        }
    }
}

@Composable
private fun TaskCard(task: TaskItem, onEdit: (TaskItem) -> Unit, onUpdate: (TaskItem) -> Unit, onDelete: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Checkbox(checked = task.completed, onCheckedChange = { onUpdate(task.copy(completed = it)) })
                Column(Modifier.weight(1f).padding(top = 3.dp)) {
                    Text(task.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, textDecoration = if (task.completed) TextDecoration.LineThrough else null)
                    val meta = buildList {
                        task.startTime?.let { add(it) }
                        task.durationMinutes?.let { add(formatDuration(it)) }
                        task.dueDate?.let { add("Entrega ${prettyDate(it)}") }
                    }.joinToString(" · ")
                    if (meta.isNotBlank()) Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Opciones") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Editar") }, onClick = { menu = false; onEdit(task) }, leadingIcon = { Icon(Icons.Default.Edit, null) })
                        DropdownMenuItem(text = { Text("Hoy") }, onClick = { menu = false; onUpdate(task.copy(doDate = LocalDate.now().toString())) })
                        DropdownMenuItem(text = { Text("Mañana") }, onClick = { menu = false; onUpdate(task.copy(doDate = LocalDate.now().plusDays(1).toString())) })
                        DropdownMenuItem(text = { Text("Mover a Sin fecha") }, onClick = { menu = false; onUpdate(task.copy(doDate = null, startTime = null)) })
                        DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete(task.id) }, leadingIcon = { Icon(Icons.Default.Delete, null) })
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                PriorityBadge(task.priority)
                if (task.category.isNotBlank()) AssistChip(onClick = {}, enabled = false, label = { Text(task.category) })
                if (task.alerts.isNotEmpty()) Text("${task.alerts.size} avisos", style = MaterialTheme.typography.labelSmall)
            }
            if (task.subtasks.isNotEmpty()) {
                val done = task.subtasks.count { it.completed }
                Text("Subtareas $done/${task.subtasks.size}", style = MaterialTheme.typography.labelMedium)
                task.subtasks.forEach { sub ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = sub.completed,
                            onCheckedChange = { checked ->
                                onUpdate(task.copy(subtasks = task.subtasks.map { if (it.id == sub.id) it.copy(completed = checked) else it }))
                            }
                        )
                        Text(sub.title, style = MaterialTheme.typography.bodyMedium, textDecoration = if (sub.completed) TextDecoration.LineThrough else null)
                    }
                }
            }
        }
    }
}

@Composable
private fun PriorityBadge(priority: Priority) {
    val label = when (priority) {
        Priority.LOW -> "Baja"
        Priority.MEDIUM -> "Media"
        Priority.HIGH -> "Alta"
        Priority.URGENT -> "Urgente"
    }
    SuggestionChip(onClick = {}, enabled = false, label = { Text(label) })
}

@Composable
private fun EventCard(event: EventItem, onEdit: (EventItem) -> Unit, onUpdate: (EventItem) -> Unit, onDelete: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.width(62.dp)) {
                Text(event.startTime, fontWeight = FontWeight.Bold)
                Text(event.endTime, style = MaterialTheme.typography.bodySmall)
            }
            Column(Modifier.weight(1f)) {
                Text(event.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (event.location.isNotBlank()) Text(event.location, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (event.alerts.isNotEmpty()) Text("${event.alerts.size} avisos", style = MaterialTheme.typography.labelSmall)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Opciones") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Editar") }, onClick = { menu = false; onEdit(event) })
                    DropdownMenuItem(text = { Text(if (event.done) "Restaurar" else "Marcar realizado") }, onClick = { menu = false; onUpdate(event.copy(done = !event.done)) })
                    DropdownMenuItem(text = { Text("Mover a mañana") }, onClick = { menu = false; onUpdate(event.copy(date = LocalDate.parse(event.date).plusDays(1).toString())) })
                    DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete(event.id) })
                }
            }
        }
    }
}

@Composable
private fun ReminderCard(reminder: ReminderItem, onEdit: (ReminderItem) -> Unit, onUpdate: (ReminderItem) -> Unit, onDelete: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Notifications, null, modifier = Modifier.padding(8.dp))
            Column(Modifier.weight(1f).padding(top = 5.dp)) {
                Text(reminder.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(reminder.time + if (reminder.alerts.isNotEmpty()) " · ${reminder.alerts.size} avisos previos" else "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (reminder.repeatUntilDone) Text("Insiste hasta atender", style = MaterialTheme.typography.labelSmall)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Opciones") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Editar") }, onClick = { menu = false; onEdit(reminder) })
                    listOf(5, 10, 15, 30, 60).forEach { mins ->
                        DropdownMenuItem(text = { Text("Posponer $mins min") }, onClick = {
                            menu = false
                            onUpdate(reminder.copy(snoozedUntilMillis = System.currentTimeMillis() + mins * 60_000L))
                        })
                    }
                    DropdownMenuItem(text = { Text(if (reminder.done) "Restaurar" else "Atendido") }, onClick = { menu = false; onUpdate(reminder.copy(done = !reminder.done)) })
                    DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete(reminder.id) })
                }
            }
        }
    }
}

@Composable
private fun UpcomingScreen(
    state: AppState,
    onTaskUpdate: (TaskItem) -> Unit,
    onEditTask: (TaskItem) -> Unit,
    onEditEvent: (EventItem) -> Unit,
    onEditReminder: (ReminderItem) -> Unit
) {
    var filter by remember { mutableStateOf<Priority?>(null) }
    val start = LocalDate.now()
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { PriorityFilter(filter) { filter = it } }
        for (i in 0..6) {
            val date = start.plusDays(i.toLong())
            val tasks = state.tasks.filter { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, date) && (filter == null || it.priority == filter) }
            val events = state.events.filter { !it.done && occursOn(it.date, it.repeat, date) }
            val rems = state.reminders.filter { !it.done && occursOn(it.date, it.repeat, date) }
            if (tasks.isNotEmpty() || events.isNotEmpty() || rems.isNotEmpty()) {
                item { SectionTitle(dateTitle(date)) }
                items(events, key = { "up-e-${date}-${it.id}" }) { e -> EventCard(e, onEditEvent, {}, {}) }
                items(tasks, key = { "up-t-${date}-${it.id}" }) { t -> TaskCard(t, onEditTask, onTaskUpdate, {}) }
                items(rems, key = { "up-r-${date}-${it.id}" }) { r -> ReminderCard(r, onEditReminder, {}, {}) }
            }
        }
    }
}

@Composable
private fun CalendarScreen(
    state: AppState,
    onTaskUpdate: (TaskItem) -> Unit,
    onEditTask: (TaskItem) -> Unit,
    onEditEvent: (EventItem) -> Unit,
    onEditReminder: (ReminderItem) -> Unit
) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    val first = month.atDay(1)
    val offset = (first.dayOfWeek.value - 1).coerceAtLeast(0)
    val cells = List(offset) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
    val rows = cells.chunked(7)
    val selectedTasks = state.tasks.filter { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, selected) }
    val selectedEvents = state.events.filter { !it.done && occursOn(it.date, it.repeat, selected) }
    val selectedRems = state.reminders.filter { !it.done && occursOn(it.date, it.repeat, selected) }

    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                IconButton(onClick = {
                    month = month.minusMonths(1)
                    selected = month.atDay(1)
                }) { Icon(Icons.Default.ChevronLeft, "Mes anterior") }
                Text(month.month.getDisplayName(TextStyle.FULL, Locale("es", "CO")).replaceFirstChar { it.uppercase() } + " ${month.year}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(onClick = {
                    month = month.plusMonths(1)
                    selected = month.atDay(1)
                }) { Icon(Icons.Default.ChevronRight, "Mes siguiente") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth()) {
                listOf("L", "M", "X", "J", "V", "S", "D").forEach { d ->
                    Text(d, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        items(rows) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                (row + List(7 - row.size) { null }).forEach { date ->
                    if (date == null) {
                        Spacer(Modifier.weight(1f).height(62.dp))
                    } else {
                        val selectedNow = date == selected
                        val count = state.tasks.count { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, date) } +
                            state.events.count { !it.done && occursOn(it.date, it.repeat, date) } +
                            state.reminders.count { !it.done && occursOn(it.date, it.repeat, date) }
                        Surface(
                            onClick = { selected = date },
                            modifier = Modifier.weight(1f).height(62.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = if (selectedNow) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        ) {
                            Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(date.dayOfMonth.toString(), fontWeight = if (selectedNow) FontWeight.Bold else FontWeight.Medium)
                                Text(date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("es", "CO")).removeSuffix("."), style = MaterialTheme.typography.labelSmall)
                                if (count > 0) Text("$count", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
        item {
            Text(dateTitle(selected), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
        if (selectedTasks.isEmpty() && selectedEvents.isEmpty() && selectedRems.isEmpty()) item { EmptyCard("No hay nada para este día.") }
        items(selectedEvents, key = { "cal-e-${it.id}" }) { e -> EventCard(e, onEditEvent, {}, {}) }
        items(selectedTasks, key = { "cal-t-${it.id}" }) { t -> TaskCard(t, onEditTask, onTaskUpdate, {}) }
        items(selectedRems, key = { "cal-r-${it.id}" }) { r -> ReminderCard(r, onEditReminder, {}, {}) }
    }
}

@Composable
private fun InboxScreen(state: AppState, onUpdate: (TaskItem) -> Unit, onEdit: (TaskItem) -> Unit, onDelete: (String) -> Unit) {
    var filter by remember { mutableStateOf<Priority?>(null) }
    val all = state.tasks.filter { !it.completed && it.doDate == null }
    val tasks = all.filter { filter == null || it.priority == filter }
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Tareas que sabes que tienes que hacer, pero todavía no tienen día.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { PriorityFilter(filter) { filter = it } }
        if (tasks.isEmpty()) item { EmptyCard(if (all.isEmpty()) "La bandeja está vacía." else "No hay tareas con este filtro.") }
        items(tasks, key = { it.id }) { TaskCard(it, onEdit, onUpdate, onDelete) }
    }
}

@Composable
private fun CompletedScreen(
    state: AppState,
    onTaskUpdate: (TaskItem) -> Unit,
    onEventUpdate: (EventItem) -> Unit,
    onReminderUpdate: (ReminderItem) -> Unit,
    onEditTask: (TaskItem) -> Unit,
    onEditEvent: (EventItem) -> Unit,
    onEditReminder: (ReminderItem) -> Unit,
    onDeleteTask: (String) -> Unit,
    onDeleteEvent: (String) -> Unit,
    onDeleteReminder: (String) -> Unit
) {
    val tasks = state.tasks.filter { it.completed }
    val events = state.events.filter { it.done }
    val rems = state.reminders.filter { it.done }
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (tasks.isEmpty() && events.isEmpty() && rems.isEmpty()) item { EmptyCard("Todavía no has completado nada.") }
        if (tasks.isNotEmpty()) {
            item { SectionTitle("Tareas completadas") }
            items(tasks, key = { "done-t-${it.id}" }) { TaskCard(it, onEditTask, onTaskUpdate, onDeleteTask) }
        }
        if (events.isNotEmpty()) {
            item { SectionTitle("Eventos realizados") }
            items(events, key = { "done-e-${it.id}" }) { EventCard(it, onEditEvent, onEventUpdate, onDeleteEvent) }
        }
        if (rems.isNotEmpty()) {
            item { SectionTitle("Recordatorios atendidos") }
            items(rems, key = { "done-r-${it.id}" }) { ReminderCard(it, onEditReminder, onReminderUpdate, onDeleteReminder) }
        }
    }
}

@Composable
private fun SettingsScreen(store: AppStore) {
    val context = LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { SectionTitle("Apariencia") }
        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Modo", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = store.state.settings.themeMode == mode,
                                onClick = { store.setThemeMode(mode) },
                                label = { Text(themeModeLabel(mode)) }
                            )
                        }
                    }
                    Text("Color de interfaz", fontWeight = FontWeight.SemiBold)
                    AccentColor.entries.forEach { color ->
                        val selected = store.state.settings.accentColor == color
                        Surface(
                            onClick = { store.setAccentColor(color) },
                            shape = RoundedCornerShape(14.dp),
                            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Surface(Modifier.size(26.dp), shape = CircleShape, color = accentPreview(color)) {}
                                Spacer(Modifier.width(10.dp))
                                Text(accentLabel(color), Modifier.weight(1f))
                                if (selected) Icon(Icons.Default.Check, "Seleccionado", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }

        item { SectionTitle("Notificaciones") }
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            item { Button(onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Permitir notificaciones") } }
        }
        item { OutlinedButton(onClick = { NotificationScheduler.showTest(context) }) { Text("Probar notificación") } }
        if (!NotificationScheduler.canExact(context)) {
            item {
                Button(onClick = { NotificationScheduler.exactAlarmSettingsIntent(context)?.let { context.startActivity(it) } }) {
                    Text("Permitir alarmas exactas")
                }
            }
        }
        item { Text("Android puede retrasar alarmas extremadamente frecuentes por ahorro de batería.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }

        item { SectionTitle("Créditos") }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Mi Día", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Idea y dirección: Samuel Flórez")
                    Text("Diseño y decisiones de producto: Samuel Flórez")
                    Text("Desarrollo colaborativo: Samuel Flórez + ChatGPT (OpenAI)")
                    Text("Versión 0.3.1", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { OutlinedButton(onClick = { store.clearAll() }) { Text("Borrar todos los datos") } }
    }
}

private fun themeModeLabel(mode: ThemeMode) = when (mode) {
    ThemeMode.SYSTEM -> "Sistema"
    ThemeMode.LIGHT -> "Día"
    ThemeMode.DARK -> "Noche"
}

private fun accentLabel(color: AccentColor) = when (color) {
    AccentColor.GREEN -> "Verde"
    AccentColor.BLUE -> "Azul"
    AccentColor.PURPLE -> "Morado"
    AccentColor.ORANGE -> "Naranja"
    AccentColor.ROSE -> "Rosa"
}

private fun accentPreview(color: AccentColor) = when (color) {
    AccentColor.GREEN -> Color(0xFF386A5F)
    AccentColor.BLUE -> Color(0xFF3D63A8)
    AccentColor.PURPLE -> Color(0xFF6A55A4)
    AccentColor.ORANGE -> Color(0xFF9A5D22)
    AccentColor.ROSE -> Color(0xFF9A4D65)
}

@Composable
private fun TypeChooser(onDismiss: () -> Unit, onChoose: (NewType) -> Unit) {
    var selected by remember { mutableStateOf(NewType.TASK) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("¿Qué quieres añadir?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NewType.entries.forEach { type ->
                    val label = when (type) {
                        NewType.TASK -> "Tarea"
                        NewType.EVENT -> "Evento"
                        NewType.REMINDER -> "Recordatorio"
                    }
                    val icon = when (type) {
                        NewType.TASK -> Icons.Default.CheckCircle
                        NewType.EVENT -> Icons.Default.Event
                        NewType.REMINDER -> Icons.Default.Notifications
                    }
                    Surface(
                        onClick = { selected = type },
                        color = if (selected == type) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(icon, null)
                            Spacer(Modifier.width(10.dp))
                            Text(label, Modifier.weight(1f), fontWeight = if (selected == type) FontWeight.Bold else FontWeight.Normal)
                            if (selected == type) Icon(Icons.Default.Check, "Seleccionado", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onChoose(selected) }) { Text("Continuar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun TaskEditDialog(existing: TaskItem?, onDismiss: () -> Unit, onSave: (TaskItem) -> Unit) {
    val base = existing ?: TaskItem(title = "", doDate = LocalDate.now().toString(), durationMinutes = 30)
    var title by remember(existing?.id) { mutableStateOf(base.title) }
    var doDate by remember(existing?.id) { mutableStateOf(base.doDate) }
    var dueDate by remember(existing?.id) { mutableStateOf(base.dueDate) }
    var startTime by remember(existing?.id) { mutableStateOf(base.startTime) }
    var duration by remember(existing?.id) { mutableStateOf(base.durationMinutes?.toString() ?: "") }
    var category by remember(existing?.id) { mutableStateOf(base.category) }
    var notes by remember(existing?.id) { mutableStateOf(base.notes) }
    var priority by remember(existing?.id) { mutableStateOf(base.priority) }
    var repeat by remember(existing?.id) { mutableStateOf(base.repeat) }
    var alerts by remember(existing?.id) { mutableStateOf(base.alerts) }
    var subtasks by remember(existing?.id) { mutableStateOf(base.subtasks) }
    var more by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Nueva tarea" else "Editar tarea") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.heightIn(max = 610.dp)) {
                item { OutlinedTextField(title, { title = it }, label = { Text("Tarea") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                item { PriorityPicker(priority) { priority = it } }
                item { DateField("Fecha para hacerla", doDate, true) { doDate = it } }
                item { DateField("Fecha límite / entrega", dueDate, true) { dueDate = it } }
                item { TimeField("Hora opcional", startTime, true) { startTime = it } }
                item { OutlinedTextField(duration, { duration = it.filter(Char::isDigit).take(4) }, label = { Text("Duración (minutos)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                item { SubTasksEditor(subtasks) { subtasks = it } }
                item { AlertsEditor(alerts, "Recordatorios de esta tarea") { alerts = it } }
                item { TextButton(onClick = { more = !more }) { Text(if (more) "Menos opciones" else "Más opciones") } }
                if (more) {
                    item { OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                    item { OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
                    item { RepeatEditor(repeat) { repeat = it } }
                }
            }
        },
        confirmButton = {
            Button(enabled = title.isNotBlank(), onClick = {
                onSave(base.copy(
                    title = title.trim(), notes = notes, category = category, priority = priority, subtasks = subtasks,
                    doDate = doDate, dueDate = dueDate, startTime = startTime,
                    durationMinutes = duration.toIntOrNull(), repeat = repeat, alerts = alerts
                ))
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun EventEditDialog(existing: EventItem?, onDismiss: () -> Unit, onSave: (EventItem) -> Unit) {
    val base = existing ?: EventItem(title = "", date = LocalDate.now().toString(), startTime = "09:00", endTime = "10:00")
    var title by remember(existing?.id) { mutableStateOf(base.title) }
    var date by remember(existing?.id) { mutableStateOf(base.date) }
    var start by remember(existing?.id) { mutableStateOf(base.startTime) }
    var end by remember(existing?.id) { mutableStateOf(base.endTime) }
    var location by remember(existing?.id) { mutableStateOf(base.location) }
    var notes by remember(existing?.id) { mutableStateOf(base.notes) }
    var repeat by remember(existing?.id) { mutableStateOf(base.repeat) }
    var alerts by remember(existing?.id) { mutableStateOf(base.alerts) }
    var more by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Nuevo evento" else "Editar evento") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.heightIn(max = 600.dp)) {
                item { OutlinedTextField(title, { title = it }, label = { Text("Evento") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                item { DateField("Fecha", date, false) { date = it ?: date } }
                item { TimeField("Inicio", start, false) { start = it ?: start } }
                item { TimeField("Fin", end, false) { end = it ?: end } }
                item { AlertsEditor(alerts, "Recordatorios de este evento") { alerts = it } }
                item { TextButton(onClick = { more = !more }) { Text(if (more) "Menos opciones" else "Más opciones") } }
                if (more) {
                    item { OutlinedTextField(location, { location = it }, label = { Text("Lugar") }, modifier = Modifier.fillMaxWidth()) }
                    item { OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
                    item { RepeatEditor(repeat) { repeat = it } }
                }
            }
        },
        confirmButton = {
            Button(enabled = title.isNotBlank(), onClick = {
                onSave(base.copy(title = title.trim(), date = date, startTime = start, endTime = end, location = location, notes = notes, repeat = repeat, alerts = alerts))
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun ReminderEditDialog(existing: ReminderItem?, onDismiss: () -> Unit, onSave: (ReminderItem) -> Unit) {
    val base = existing ?: ReminderItem(title = "", date = LocalDate.now().toString(), time = LocalTime.now().withSecond(0).withNano(0).toString())
    var title by remember(existing?.id) { mutableStateOf(base.title) }
    var date by remember(existing?.id) { mutableStateOf(base.date) }
    var time by remember(existing?.id) { mutableStateOf(base.time) }
    var notes by remember(existing?.id) { mutableStateOf(base.notes) }
    var repeat by remember(existing?.id) { mutableStateOf(base.repeat) }
    var repeatUntilDone by remember(existing?.id) { mutableStateOf(base.repeatUntilDone) }
    var alerts by remember(existing?.id) { mutableStateOf(base.alerts) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Nuevo recordatorio" else "Editar recordatorio") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.heightIn(max = 590.dp)) {
                item { OutlinedTextField(title, { title = it }, label = { Text("Recordatorio") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                item { DateField("Fecha", date, false) { date = it ?: date } }
                item { TimeField("Hora", time, false) { time = it ?: time } }
                item { AlertsEditor(alerts, "Avisos adicionales antes del recordatorio") { alerts = it } }
                item { OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
                item { RepeatEditor(repeat) { repeat = it } }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(repeatUntilDone, { repeatUntilDone = it })
                        Text("Insistir hasta marcarlo como atendido")
                    }
                }
            }
        },
        confirmButton = {
            Button(enabled = title.isNotBlank(), onClick = {
                onSave(base.copy(title = title.trim(), date = date, time = time, notes = notes, repeat = repeat, repeatUntilDone = repeatUntilDone, snoozedUntilMillis = null, alerts = alerts))
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun PriorityPicker(value: Priority, onChange: (Priority) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text("Prioridad", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Priority.entries.forEach { p ->
                FilterChip(selected = p == value, onClick = { onChange(p) }, label = {
                    Text(when (p) {
                        Priority.LOW -> "Baja"
                        Priority.MEDIUM -> "Media"
                        Priority.HIGH -> "Alta"
                        Priority.URGENT -> "Urgente"
                    })
                })
            }
        }
    }
}

@Composable
private fun SubTasksEditor(value: List<SubTask>, onChange: (List<SubTask>) -> Unit) {
    var newTitle by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text("Subtareas", style = MaterialTheme.typography.labelMedium)
        value.forEach { sub ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(sub.completed, { checked -> onChange(value.map { if (it.id == sub.id) it.copy(completed = checked) else it }) })
                OutlinedTextField(
                    value = sub.title,
                    onValueChange = { text -> onChange(value.map { if (it.id == sub.id) it.copy(title = text) else it }) },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                IconButton(onClick = { onChange(value.filterNot { it.id == sub.id }) }) { Icon(Icons.Default.Close, "Eliminar subtarea") }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(newTitle, { newTitle = it }, label = { Text("Nueva subtarea") }, modifier = Modifier.weight(1f), singleLine = true)
            IconButton(enabled = newTitle.isNotBlank(), onClick = {
                onChange(value + SubTask(title = newTitle.trim()))
                newTitle = ""
            }) { Icon(Icons.Default.Add, "Añadir subtarea") }
        }
    }
}

@Composable
private fun DateField(label: String, value: String?, allowNone: Boolean, onChange: (String?) -> Unit) {
    val context = LocalContext.current
    val current = value?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: LocalDate.now()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        OutlinedButton(onClick = {
            DatePickerDialog(context, { _, y, m, d -> onChange(LocalDate.of(y, m + 1, d).toString()) }, current.year, current.monthValue - 1, current.dayOfMonth).show()
        }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.CalendarMonth, null)
            Spacer(Modifier.width(8.dp))
            Text(value?.let(::prettyDateLong) ?: "Sin fecha")
        }
        val today = LocalDate.now()
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            AssistChip(onClick = { onChange(today.toString()) }, label = { Text("Hoy") })
            AssistChip(onClick = { onChange(today.plusDays(1).toString()) }, label = { Text("Mañana") })
            AssistChip(onClick = { onChange(today.plusWeeks(1).toString()) }, label = { Text("+1 semana") })
        }
        if (allowNone) {
            AssistChip(onClick = { onChange(null) }, label = { Text("Quitar fecha") })
        }
    }
}

@Composable
private fun TimeField(label: String, value: String?, allowNone: Boolean, onChange: (String?) -> Unit) {
    val context = LocalContext.current
    val current = value?.let { runCatching { LocalTime.parse(it) }.getOrNull() } ?: LocalTime.now()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        OutlinedButton(onClick = {
            TimePickerDialog(context, { _, h, m -> onChange(LocalTime.of(h, m).toString()) }, current.hour, current.minute, true).show()
        }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Schedule, null)
            Spacer(Modifier.width(8.dp))
            Text(value ?: "Sin hora")
        }
        val now = LocalTime.now().withSecond(0).withNano(0)
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            AssistChip(onClick = { onChange(now.toString()) }, label = { Text("Ahora") })
            AssistChip(onClick = { onChange("09:00") }, label = { Text("09:00") })
            AssistChip(onClick = { onChange("12:00") }, label = { Text("12:00") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            AssistChip(onClick = { onChange("18:00") }, label = { Text("18:00") })
            if (allowNone) AssistChip(onClick = { onChange(null) }, label = { Text("Quitar hora") })
        }
    }
}

@Composable
private fun RepeatEditor(value: RepeatRule, onChange: (RepeatRule) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var interval by remember(value.interval) { mutableStateOf(value.interval.toString()) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Repetición", style = MaterialTheme.typography.labelMedium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box {
                OutlinedButton(onClick = { menu = true }) { Text(repeatLabel(value.unit)) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    RepeatUnit.entries.forEach { unit ->
                        DropdownMenuItem(text = { Text(repeatLabel(unit)) }, onClick = { menu = false; onChange(value.copy(unit = unit)) })
                    }
                }
            }
            if (value.unit != RepeatUnit.NONE) {
                OutlinedTextField(
                    interval,
                    { s ->
                        interval = s.filter(Char::isDigit).take(4)
                        onChange(value.copy(interval = interval.toIntOrNull()?.coerceAtLeast(1) ?: 1))
                    },
                    label = { Text("Cada") },
                    modifier = Modifier.width(100.dp),
                    singleLine = true
                )
            }
        }
    }
}

private fun repeatLabel(unit: RepeatUnit) = when (unit) {
    RepeatUnit.NONE -> "No repetir"
    RepeatUnit.MINUTES -> "Minutos"
    RepeatUnit.HOURS -> "Horas"
    RepeatUnit.DAYS -> "Días"
    RepeatUnit.WEEKS -> "Semanas"
    RepeatUnit.MONTHS -> "Meses"
    RepeatUnit.YEARS -> "Años"
}

@Composable
private fun AlertsEditor(value: List<Int>, title: String, onChange: (List<Int>) -> Unit) {
    var custom by remember { mutableStateOf("") }
    val presets = listOf(0 to "A la hora", 5 to "5 min", 15 to "15 min", 30 to "30 min", 60 to "1 h", 1440 to "1 día")
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, style = MaterialTheme.typography.labelMedium)
        presets.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                row.forEach { (min, label) ->
                    FilterChip(
                        selected = min in value,
                        onClick = { onChange(if (min in value) value - min else (value + min).distinct().sorted()) },
                        label = { Text(label) }
                    )
                }
            }
        }
        if (value.isNotEmpty()) {
            Text("Añadidos: ${value.size}", style = MaterialTheme.typography.bodySmall)
            value.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    row.forEach { min ->
                        InputChip(
                            selected = true,
                            onClick = { onChange(value - min) },
                            label = { Text(alertLabel(min)) },
                            trailingIcon = { Icon(Icons.Default.Close, "Quitar") }
                        )
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(custom, { custom = it.filter(Char::isDigit).take(6) }, label = { Text("Minutos antes") }, modifier = Modifier.weight(1f), singleLine = true)
            Button(onClick = {
                custom.toIntOrNull()?.coerceAtLeast(0)?.let { onChange((value + it).distinct().sorted()); custom = "" }
            }, enabled = custom.toIntOrNull() != null) { Text("Añadir") }
        }
        Text("Puedes añadir todos los avisos que necesites.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun alertLabel(min: Int) = when (min) {
    0 -> "A la hora"
    60 -> "1 h antes"
    1440 -> "1 día antes"
    else -> "$min min antes"
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
private fun SummaryPill(text: String) {
    Surface(shape = RoundedCornerShape(100.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Text(text, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun EmptyCard(text: String) {
    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)) {
        Text(text, Modifier.fillMaxWidth().padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun prettyDate(raw: String): String = runCatching {
    LocalDate.parse(raw).format(DateTimeFormatter.ofPattern("d MMM", Locale("es", "CO")))
}.getOrDefault(raw)

private fun prettyDateLong(raw: String): String = runCatching {
    LocalDate.parse(raw).format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale("es", "CO"))).replaceFirstChar { it.uppercase() }
}.getOrDefault(raw)

private fun dateTitle(date: LocalDate): String = date.format(
    DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale("es", "CO"))
).replaceFirstChar { it.uppercase() }
