package com.midia.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationScheduler.createChannel(this)
        setContent { MiDiaApp() }
    }
}

enum class AppTab(val label: String) { TODAY("Hoy"), UPCOMING("Próximos"), CALENDAR("Calendario"), INBOX("Sin fecha"), COMPLETED("Hechas"), SETTINGS("Ajustes") }
enum class NewType { TASK, EVENT, REMINDER }

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun MiDiaApp() {
    val context = LocalContext.current
    val store = remember { AppStore(context.applicationContext) }
    var tab by remember { mutableStateOf(AppTab.TODAY) }
    var chooser by remember { mutableStateOf(false) }
    var taskEdit by remember { mutableStateOf<TaskItem?>(null) }
    var taskDialogOpen by remember { mutableStateOf(false) }
    var eventEdit by remember { mutableStateOf<EventItem?>(null) }
    var eventDialogOpen by remember { mutableStateOf(false) }
    var reminderEdit by remember { mutableStateOf<ReminderItem?>(null) }
    var reminderDialogOpen by remember { mutableStateOf(false) }
    var slotTask by remember { mutableStateOf<TaskItem?>(null) }

    LaunchedEffect(Unit) { NotificationScheduler.rescheduleAll(context, store.state) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF385B55),
            secondary = androidx.compose.ui.graphics.Color(0xFF5F6B9A),
            tertiary = androidx.compose.ui.graphics.Color(0xFFA26B26),
            background = androidx.compose.ui.graphics.Color(0xFFFAF8F5),
            surface = androidx.compose.ui.graphics.Color.White
        )
    ) {
        Scaffold(
            topBar = { TopAppBar(title = { Text(if (tab == AppTab.TODAY) "Mi Día" else tab.label) }) },
            floatingActionButton = {
                if (tab != AppTab.SETTINGS) FloatingActionButton(onClick = { chooser = true }) { Icon(Icons.Default.Add, "Añadir") }
            },
            bottomBar = {
                NavigationBar {
                    val icons = mapOf(
                        AppTab.TODAY to Icons.Default.Today,
                        AppTab.UPCOMING to Icons.Default.DateRange,
                        AppTab.CALENDAR to Icons.Default.CalendarMonth,
                        AppTab.INBOX to Icons.Default.Inbox,
                        AppTab.COMPLETED to Icons.Default.DoneAll,
                        AppTab.SETTINGS to Icons.Default.Settings
                    )
                    AppTab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(icons.getValue(t), t.label) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    AppTab.TODAY -> TodayScreen(
                        state = store.state,
                        onEditTask = { taskEdit = it; taskDialogOpen = true },
                        onEditEvent = { eventEdit = it; eventDialogOpen = true },
                        onEditReminder = { reminderEdit = it; reminderDialogOpen = true },
                        onTaskUpdate = store::replaceTask,
                        onEventUpdate = store::replaceEvent,
                        onReminderUpdate = store::replaceReminder,
                        onDeleteTask = store::deleteTask,
                        onDeleteEvent = store::deleteEvent,
                        onDeleteReminder = store::deleteReminder,
                        onAddTaskToSlot = { slot ->
                            taskEdit = TaskItem(
                                title = "",
                                doDate = LocalDate.now().toString(),
                                startTime = minutesToTime(slot.startMinutes).toString(),
                                durationMinutes = minOf(60, slot.endMinutes - slot.startMinutes)
                            )
                            taskDialogOpen = true
                        },
                        onMoveTaskToSlot = { slotTask = it },
                        onSaveFreeSlots = { slots -> store.setFreeSlotsForDate(LocalDate.now().toString(), slots) },
                        onResetFreeSlots = { store.resetFreeSlotsForDate(LocalDate.now().toString()) }
                    )
                    AppTab.UPCOMING -> UpcomingScreen(store.state, store::replaceTask, { taskEdit = it; taskDialogOpen = true }, { eventEdit = it; eventDialogOpen = true }, { reminderEdit = it; reminderDialogOpen = true })
                    AppTab.CALENDAR -> CalendarScreen(store.state, { taskEdit = it; taskDialogOpen = true }, { eventEdit = it; eventDialogOpen = true }, { reminderEdit = it; reminderDialogOpen = true })
                    AppTab.INBOX -> InboxScreen(store.state, store::replaceTask, { taskEdit = it; taskDialogOpen = true }, store::deleteTask)
                    AppTab.COMPLETED -> CompletedScreen(
                        store.state, store::replaceTask, store::replaceEvent, store::replaceReminder,
                        { taskEdit = it; taskDialogOpen = true },
                        { eventEdit = it; eventDialogOpen = true },
                        { reminderEdit = it; reminderDialogOpen = true },
                        store::deleteTask, store::deleteEvent, store::deleteReminder
                    )
                    AppTab.SETTINGS -> SettingsScreen(store)
                }
            }
        }

        if (chooser) TypeChooser(onDismiss = { chooser = false }) { type ->
            chooser = false
            when (type) {
                NewType.TASK -> { taskEdit = null; taskDialogOpen = true }
                NewType.EVENT -> { eventEdit = null; eventDialogOpen = true }
                NewType.REMINDER -> { reminderEdit = null; reminderDialogOpen = true }
            }
        }

        if (taskDialogOpen) TaskEditDialog(
            existing = taskEdit,
            onDismiss = { taskDialogOpen = false; taskEdit = null },
            onSave = { item ->
                if (store.state.tasks.any { it.id == item.id }) store.replaceTask(item) else store.addTask(item)
                taskDialogOpen = false; taskEdit = null
            }
        )
        if (eventDialogOpen) EventEditDialog(
            existing = eventEdit,
            onDismiss = { eventDialogOpen = false; eventEdit = null },
            onSave = { item ->
                if (store.state.events.any { it.id == item.id }) store.replaceEvent(item) else store.addEvent(item)
                eventDialogOpen = false; eventEdit = null
            }
        )
        if (reminderDialogOpen) ReminderEditDialog(
            existing = reminderEdit,
            onDismiss = { reminderDialogOpen = false; reminderEdit = null },
            onSave = { item ->
                if (store.state.reminders.any { it.id == item.id }) store.replaceReminder(item) else store.addReminder(item)
                reminderDialogOpen = false; reminderEdit = null
            }
        )
        slotTask?.let { task ->
            SlotPickerDialog(task, store.state, onDismiss = { slotTask = null }) { moved ->
                store.replaceTask(moved); slotTask = null
            }
        }
    }
}

@Composable
private fun TodayScreen(
    state: AppState,
    onEditTask: (TaskItem) -> Unit,
    onEditEvent: (EventItem) -> Unit,
    onEditReminder: (ReminderItem) -> Unit,
    onTaskUpdate: (TaskItem) -> Unit,
    onEventUpdate: (EventItem) -> Unit,
    onReminderUpdate: (ReminderItem) -> Unit,
    onDeleteTask: (String) -> Unit,
    onDeleteEvent: (String) -> Unit,
    onDeleteReminder: (String) -> Unit,
    onAddTaskToSlot: (TimeSlot) -> Unit,
    onMoveTaskToSlot: (TaskItem) -> Unit,
    onSaveFreeSlots: (List<TimeSlot>) -> Unit,
    onResetFreeSlots: () -> Unit
) {
    val today = LocalDate.now()
    val tasks = state.tasks.filter { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, today) }
    val events = state.events.filter { !it.done && occursOn(it.date, it.repeat, today) }.sortedBy { it.startTime }
    val reminders = state.reminders.filter { !it.done && occursOn(it.date, it.repeat, today) }.sortedBy { it.time }
    val overdue = state.tasks.filter { !it.completed && it.doDate != null && runCatching { LocalDate.parse(it.doDate) }.getOrNull()?.isBefore(today) == true && it.repeat.unit == RepeatUnit.NONE }

    var draggingTask by remember { mutableStateOf<TaskItem?>(null) }
    var dragPoint by remember { mutableStateOf<Offset?>(null) }
    var editingSlot by remember { mutableStateOf<TimeSlot?>(null) }
    val slotBounds = remember { mutableStateMapOf<String, Rect>() }
    fun key(slot: TimeSlot) = "${slot.startMinutes}-${slot.endMinutes}"

    val slotState = draggingTask?.let { dragged -> state.copy(tasks = state.tasks.filterNot { it.id == dragged.id }) } ?: state
    val slots = freeSlotsForDay(slotState, today)
    val hasManualSlots = state.freeSlotOverrides.any { it.date == today.toString() }

    fun finishDrag() {
        val task = draggingTask
        val point = dragPoint
        val target = if (point != null) slots.firstOrNull { slotBounds[key(it)]?.contains(point) == true } else null
        if (task != null && target != null) {
            onTaskUpdate(
                task.copy(
                    doDate = today.toString(),
                    startTime = minutesToTime(target.startMinutes).toString(),
                    durationMinutes = minOf(task.durationMinutes ?: 30, target.endMinutes - target.startMinutes)
                )
            )
        }
        draggingTask = null
        dragPoint = null
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(today.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale("es", "CO"))).replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryPill("${tasks.size} tareas")
                SummaryPill("${events.size} eventos")
                SummaryPill("${reminders.size} avisos")
            }
        }

        item { SectionTitle("Agenda y espacios libres") }
        if (hasManualSlots) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onResetFreeSlots) { Text("Volver a franjas automáticas") }
                }
            }
        }
        if (events.isEmpty()) item { EmptyCard("No tienes eventos hoy.") }
        items(events, key = { "e${it.id}" }) { event -> EventCard(event, onEditEvent, onEventUpdate, onDeleteEvent) }
        items(slots.take(8), key = { "s${key(it)}" }) { slot ->
            val boundsModifier = Modifier.onGloballyPositioned { coordinates -> slotBounds[key(slot)] = coordinates.boundsInWindow() }
            val highlighted = dragPoint?.let { p -> slotBounds[key(slot)]?.contains(p) == true } == true
            FreeSlotCard(
                slot = slot,
                modifier = boundsModifier,
                highlighted = highlighted,
                dragging = draggingTask != null,
                onAdd = { onAddTaskToSlot(slot) },
                onEdit = { editingSlot = slot }
            )
        }

        item { SectionTitle("Tareas de hoy") }
        if (draggingTask == null) item { Text("Mantén presionado el asa ↕ de una tarea y suéltala sobre una franja libre.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (tasks.isEmpty()) item { EmptyCard("No tienes tareas para hoy.") }
        items(tasks, key = { "t${it.id}" }) { task ->
            TaskCard(
                task, onEditTask, onTaskUpdate, onDeleteTask, onMoveTaskToSlot,
                dragEnabled = true,
                onDragStart = { item, point -> draggingTask = item; dragPoint = point },
                onDragMove = { dragPoint = it },
                onDragEnd = ::finishDrag,
                onDragCancel = { draggingTask = null; dragPoint = null }
            )
        }

        item { SectionTitle("Recordatorios") }
        if (reminders.isEmpty()) item { EmptyCard("No tienes recordatorios hoy.") }
        items(reminders, key = { "r${it.id}" }) { reminder -> ReminderCard(reminder, onEditReminder, onReminderUpdate, onDeleteReminder) }

        if (overdue.isNotEmpty()) {
            item { SectionTitle("Pendientes anteriores") }
            items(overdue, key = { "o${it.id}" }) { task -> TaskCard(task, onEditTask, onTaskUpdate, onDeleteTask, onMoveTaskToSlot, overdue = true) }
        }

        val noDate = state.tasks.count { !it.completed && it.doDate == null }
        if (noDate > 0) item { Text("$noDate tareas siguen en Sin fecha para organizarlas después.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }

    editingSlot?.let { original ->
        FreeSlotEditDialog(
            slot = original,
            onDismiss = { editingSlot = null },
            onSave = { updated ->
                val baseSlots = freeSlotsForDay(state, today)
                val replaced = baseSlots.map { if (it.startMinutes == original.startMinutes && it.endMinutes == original.endMinutes) updated else it }
                onSaveFreeSlots(replaced)
                editingSlot = null
            }
        )
    }
}

@Composable private fun SummaryPill(text: String) { Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.secondaryContainer) { Text(text, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium) } }
@Composable private fun SectionTitle(text: String) { Text(text.uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
@Composable private fun EmptyCard(text: String) { OutlinedCard(Modifier.fillMaxWidth()) { Text(text, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@Composable
private fun FreeSlotCard(
    slot: TimeSlot,
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    dragging: Boolean = false,
    onAdd: () -> Unit,
    onEdit: () -> Unit
) {
    val colors = if (highlighted) CardDefaults.outlinedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer) else CardDefaults.outlinedCardColors()
    OutlinedCard(modifier.fillMaxWidth(), colors = colors) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (dragging) Icons.Default.Download else Icons.Default.Schedule, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(if (highlighted) "Suelta la tarea aquí" else "${minutesToTime(slot.startMinutes)} – ${minutesToTime(slot.endMinutes)} libre", fontWeight = FontWeight.Medium)
                Text("${slot.endMinutes - slot.startMinutes} min disponibles", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Editar franja") }
            TextButton(onClick = onAdd) { Text("Añadir") }
        }
    }
}

@Composable
private fun TaskCard(
    task: TaskItem,
    onEdit: (TaskItem) -> Unit,
    onUpdate: (TaskItem) -> Unit,
    onDelete: (String) -> Unit,
    onMoveSlot: (TaskItem) -> Unit,
    overdue: Boolean = false,
    dragEnabled: Boolean = false,
    onDragStart: (TaskItem, Offset) -> Unit = { _, _ -> },
    onDragMove: (Offset) -> Unit = {},
    onDragEnd: () -> Unit = {},
    onDragCancel: () -> Unit = {}
) {
    var menu by remember { mutableStateOf(false) }
    var dragCoordinates by remember { mutableStateOf<LayoutCoordinates?>(null) }
    OutlinedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
            Checkbox(checked = task.completed, onCheckedChange = { onUpdate(task.copy(completed = it)) })
            Column(Modifier.weight(1f).padding(top = 4.dp)) {
                Text(task.title, fontWeight = FontWeight.Medium, textDecoration = if (task.completed) TextDecoration.LineThrough else null)
                val meta = buildList {
                    task.startTime?.let { add("$it${task.durationMinutes?.let { d -> " · $d min" } ?: ""}") }
                    task.dueDate?.let { add("Entrega: $it") }
                    task.category.takeIf { it.isNotBlank() }?.let(::add)
                    if (task.repeat.unit != RepeatUnit.NONE) add("Cada ${task.repeat.interval} ${task.repeat.unit.name.lowercase()}")
                    if (task.alerts.isNotEmpty()) add("${task.alerts.size} aviso(s)")
                }
                if (meta.isNotEmpty()) Text(meta.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = if (overdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (dragEnabled && !task.completed) {
                Icon(
                    Icons.Default.DragIndicator,
                    "Mantener presionado para arrastrar",
                    modifier = Modifier
                        .size(44.dp)
                        .padding(10.dp)
                        .onGloballyPositioned { dragCoordinates = it }
                        .pointerInput(task.id) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = { offset -> dragCoordinates?.localToWindow(offset)?.let { onDragStart(task, it) } },
                                onDrag = { change, _ -> change.consume(); dragCoordinates?.localToWindow(change.position)?.let(onDragMove) },
                                onDragEnd = onDragEnd,
                                onDragCancel = onDragCancel
                            )
                        },
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Opciones") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Editar") }, onClick = { menu = false; onEdit(task) })
                    DropdownMenuItem(text = { Text("Mover a franja libre") }, onClick = { menu = false; onMoveSlot(task) })
                    DropdownMenuItem(text = { Text("Mover a hoy") }, onClick = { menu = false; onUpdate(task.copy(doDate = LocalDate.now().toString())) })
                    DropdownMenuItem(text = { Text("Mover a mañana") }, onClick = { menu = false; onUpdate(task.copy(doDate = LocalDate.now().plusDays(1).toString())) })
                    DropdownMenuItem(text = { Text("Dejar sin fecha") }, onClick = { menu = false; onUpdate(task.copy(doDate = null, startTime = null, durationMinutes = null)) })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete(task.id) }, colors = MenuDefaults.itemColors(textColor = MaterialTheme.colorScheme.error))
                }
            }
        }
    }
}

@Composable
private fun EventCard(event: EventItem, onEdit: (EventItem) -> Unit, onUpdate: (EventItem) -> Unit, onDelete: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    OutlinedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.width(58.dp)) { Text(event.startTime, fontWeight = FontWeight.Bold); Text(event.endTime, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Column(Modifier.weight(1f)) {
                Text(event.title, fontWeight = FontWeight.Medium)
                if (event.location.isNotBlank()) Text(event.location, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (event.repeat.unit != RepeatUnit.NONE) Text("Repite cada ${event.repeat.interval} ${event.repeat.unit.name.lowercase()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Opciones") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Editar") }, onClick = { menu = false; onEdit(event) })
                    DropdownMenuItem(text = { Text("Mover a mañana") }, onClick = { menu = false; onUpdate(event.copy(date = LocalDate.parse(event.date).plusDays(1).toString())) })
                    DropdownMenuItem(text = { Text(if (event.done) "Marcar pendiente" else "Marcar realizado") }, onClick = { menu = false; onUpdate(event.copy(done = !event.done)) })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete(event.id) }, colors = MenuDefaults.itemColors(textColor = MaterialTheme.colorScheme.error))
                }
            }
        }
    }
}

@Composable
private fun ReminderCard(reminder: ReminderItem, onEdit: (ReminderItem) -> Unit, onUpdate: (ReminderItem) -> Unit, onDelete: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    OutlinedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Notifications, null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.padding(top = 3.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(reminder.title, fontWeight = FontWeight.Medium)
                Text(buildString { append(reminder.time); if (reminder.repeatUntilDone) append(" · insiste hasta atender") }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Opciones") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Editar") }, onClick = { menu = false; onEdit(reminder) })
                    listOf(5, 10, 15, 30, 60).forEach { mins -> DropdownMenuItem(text = { Text("Posponer $mins min") }, onClick = { menu = false; onUpdate(reminder.copy(snoozedUntilMillis = System.currentTimeMillis() + mins * 60_000L)) }) }
                    DropdownMenuItem(text = { Text("Posponer a mañana") }, onClick = { menu = false; onUpdate(reminder.copy(date = LocalDate.parse(reminder.date).plusDays(1).toString(), snoozedUntilMillis = null)) })
                    DropdownMenuItem(text = { Text(if (reminder.done) "Marcar pendiente" else "Marcar atendido") }, onClick = { menu = false; onUpdate(reminder.copy(done = !reminder.done)) })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete(reminder.id) }, colors = MenuDefaults.itemColors(textColor = MaterialTheme.colorScheme.error))
                }
            }
        }
    }
}

@Composable
private fun UpcomingScreen(state: AppState, onTaskUpdate: (TaskItem) -> Unit, onEditTask: (TaskItem) -> Unit, onEditEvent: (EventItem) -> Unit, onEditReminder: (ReminderItem) -> Unit) {
    val start = LocalDate.now()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        (0L..6L).forEach { offset ->
            val date = start.plusDays(offset)
            val tasks = state.tasks.filter { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, date) }
            val events = state.events.filter { !it.done && occursOn(it.date, it.repeat, date) }.sortedBy { it.startTime }
            val reminders = state.reminders.filter { !it.done && occursOn(it.date, it.repeat, date) }.sortedBy { it.time }
            item(key = "d$date") { SectionTitle(if (offset == 0L) "Hoy" else date.format(DateTimeFormatter.ofPattern("EEEE d MMM", Locale("es", "CO")))) }
            items(events, key = { "ue${date}${it.id}" }) { EventCard(it, onEditEvent, { _ -> }, { _ -> }) }
            items(tasks, key = { "ut${date}${it.id}" }) { TaskCard(it, onEditTask, onTaskUpdate, { _ -> }, { _ -> }) }
            items(reminders, key = { "ur${date}${it.id}" }) { ReminderCard(it, onEditReminder, { _ -> }, { _ -> }) }
            if (tasks.isEmpty() && events.isEmpty() && reminders.isEmpty()) item(key = "empty$date") { Text("Sin planes", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 4.dp)) }
        }
    }
}

@Composable
private fun CalendarScreen(state: AppState, onEditTask: (TaskItem) -> Unit, onEditEvent: (EventItem) -> Unit, onEditReminder: (ReminderItem) -> Unit) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Default.ChevronLeft, "Mes anterior") }
            Text("${month.month.getDisplayName(TextStyle.FULL, Locale("es", "CO"))} ${month.year}".replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.Bold)
            IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Default.ChevronRight, "Mes siguiente") }
        }
        val first = month.atDay(1)
        val offset = (first.dayOfWeek.value - 1).coerceAtLeast(0)
        val days = month.lengthOfMonth()
        for (week in 0..5) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0..6) {
                    val day = week * 7 + col - offset + 1
                    Box(Modifier.weight(1f).padding(2.dp)) {
                        if (day in 1..days) {
                            val date = month.atDay(day)
                            val count = state.tasks.count { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, date) } + state.events.count { !it.done && occursOn(it.date, it.repeat, date) } + state.reminders.count { !it.done && occursOn(it.date, it.repeat, date) }
                            FilledTonalButton(onClick = { selected = date }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(4.dp), colors = if (selected == date) ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer) else ButtonDefaults.filledTonalButtonColors()) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(day.toString(), fontWeight = FontWeight.Bold)
                                    Text(date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("es", "CO")).removeSuffix(".").take(3), style = MaterialTheme.typography.labelSmall)
                                    if (count > 0) Text("• $count", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text(selected.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale("es", "CO"))).replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.Bold)
        val tasks = state.tasks.filter { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, selected) }
        val events = state.events.filter { !it.done && occursOn(it.date, it.repeat, selected) }
        val reminders = state.reminders.filter { !it.done && occursOn(it.date, it.repeat, selected) }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
            items(events) { EventCard(it, onEditEvent, { _ -> }, { _ -> }) }
            items(tasks) { TaskCard(it, onEditTask, { _ -> }, { _ -> }, { _ -> }) }
            items(reminders) { ReminderCard(it, onEditReminder, { _ -> }, { _ -> }) }
            if (tasks.isEmpty() && events.isEmpty() && reminders.isEmpty()) item { EmptyCard("No hay nada este día.") }
        }
    }
}

@Composable
private fun InboxScreen(state: AppState, onUpdate: (TaskItem) -> Unit, onEdit: (TaskItem) -> Unit, onDelete: (String) -> Unit) {
    val tasks = state.tasks.filter { !it.completed && it.doDate == null }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Aquí guardas cosas que tienes que hacer, pero todavía no sabes cuándo.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(tasks, key = { it.id }) { task -> TaskCard(task, onEdit, onUpdate, onDelete, { _ -> }) }
        if (tasks.isEmpty()) item { EmptyCard("No tienes tareas sin fecha.") }
    }
}

@Composable
private fun CompletedScreen(
    state: AppState,
    onTaskUpdate: (TaskItem) -> Unit,
    onEventUpdate: (EventItem) -> Unit,
    onReminderUpdate: (ReminderItem) -> Unit,
    onEditTask: (TaskItem) -> Unit,
    onEditEvent: (EventItem) -> Unit,
    onEditReminder: (ReminderItem) -> Unit,
    onDeleteTask: (String) -> Unit,
    onDeleteEvent: (String) -> Unit,
    onDeleteReminder: (String) -> Unit
) {
    val tasks = state.tasks.filter { it.completed }.sortedByDescending { it.doDate ?: "" }
    val events = state.events.filter { it.done }.sortedByDescending { it.date }
    val reminders = state.reminders.filter { it.done }.sortedByDescending { "${it.date} ${it.time}" }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Todo lo que ya terminaste queda aquí. Puedes restaurarlo si lo necesitas.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { SectionTitle("Tareas completadas") }
        if (tasks.isEmpty()) item { EmptyCard("Todavía no has completado tareas.") }
        items(tasks, key = { "ct${it.id}" }) { TaskCard(it, onEditTask, onTaskUpdate, onDeleteTask, { _ -> }) }
        item { SectionTitle("Eventos realizados") }
        if (events.isEmpty()) item { EmptyCard("No hay eventos marcados como realizados.") }
        items(events, key = { "ce${it.id}" }) { EventCard(it, onEditEvent, onEventUpdate, onDeleteEvent) }
        item { SectionTitle("Recordatorios atendidos") }
        if (reminders.isEmpty()) item { EmptyCard("No hay recordatorios atendidos.") }
        items(reminders, key = { "cr${it.id}" }) { ReminderCard(it, onEditReminder, onReminderUpdate, onDeleteReminder) }
    }
}

@Composable
private fun SettingsScreen(store: AppStore) {
    val context = LocalContext.current
    var notifGranted by remember { mutableStateOf(Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notifGranted = it }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Notificaciones", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item {
            OutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (notifGranted) "Permiso de notificaciones: activado" else "Permiso de notificaciones: pendiente")
                    if (!notifGranted && Build.VERSION.SDK_INT >= 33) Button(onClick = { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Permitir notificaciones") }
                    Button(onClick = { NotificationScheduler.showTest(context) }, enabled = notifGranted) { Text("Probar notificación") }
                    Text(if (NotificationScheduler.canExact(context)) "Alarmas exactas: activadas" else "Para mayor precisión, permite alarmas y recordatorios exactos.", style = MaterialTheme.typography.bodySmall)
                    NotificationScheduler.exactAlarmSettingsIntent(context)?.let { intent -> OutlinedButton(onClick = { context.startActivity(intent) }) { Text("Permitir alarmas exactas") } }
                    Text("Android puede limitar repeticiones extremadamente frecuentes para ahorrar batería. La app intenta usar AlarmManager y, si no tiene permiso exacto, usa el modo permitido por el sistema.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { OutlinedButton(onClick = { store.clearAll() }, colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Borrar todos mis datos") } }
    }
}

@Composable
private fun TypeChooser(onDismiss: () -> Unit, onChoose: (NewType) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("¿Qué quieres añadir?") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onChoose(NewType.TASK) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(8.dp)); Text("Tarea") }
            OutlinedButton(onClick = { onChoose(NewType.EVENT) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Event, null); Spacer(Modifier.width(8.dp)); Text("Evento") }
            OutlinedButton(onClick = { onChoose(NewType.REMINDER) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Notifications, null); Spacer(Modifier.width(8.dp)); Text("Recordatorio") }
        }
    }, confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
private fun TaskEditDialog(existing: TaskItem?, onDismiss: () -> Unit, onSave: (TaskItem) -> Unit) {
    val base = existing ?: TaskItem(title = "", doDate = LocalDate.now().toString())
    var title by remember(existing?.id) { mutableStateOf(base.title) }
    var notes by remember(existing?.id) { mutableStateOf(base.notes) }
    var category by remember(existing?.id) { mutableStateOf(base.category) }
    var doDate by remember(existing?.id) { mutableStateOf(base.doDate) }
    var dueDate by remember(existing?.id) { mutableStateOf(base.dueDate) }
    var startTime by remember(existing?.id) { mutableStateOf(base.startTime) }
    var duration by remember(existing?.id) { mutableStateOf(base.durationMinutes?.toString() ?: "") }
    var repeat by remember(existing?.id) { mutableStateOf(base.repeat) }
    var alerts by remember(existing?.id) { mutableStateOf(base.alerts) }
    var more by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null || existing.title.isBlank()) "Nueva tarea" else "Editar tarea") }, text = {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 560.dp)) {
            item { OutlinedTextField(title, { title = it }, label = { Text("Tarea") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { DateField("Día para hacerla", doDate, allowNone = true) { doDate = it } }
            item { DateField("Fecha límite / entrega", dueDate, allowNone = true) { dueDate = it } }
            item { TimeField("Hora opcional", startTime, allowNone = true) { startTime = it } }
            item { OutlinedTextField(duration, { duration = it.filter(Char::isDigit).take(4) }, label = { Text("Duración en minutos (opcional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { TextButton(onClick = { more = !more }) { Text(if (more) "Menos opciones" else "Más opciones") } }
            if (more) {
                item { OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                item { OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
                item { RepeatEditor(repeat) { repeat = it } }
                item { AlertsEditor(alerts) { alerts = it } }
            }
        }
    }, confirmButton = {
        Button(enabled = title.isNotBlank(), onClick = {
            onSave(base.copy(title = title.trim(), notes = notes, category = category, doDate = doDate, dueDate = dueDate, startTime = startTime, durationMinutes = duration.toIntOrNull(), repeat = repeat, alerts = alerts))
        }) { Text("Guardar") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
private fun EventEditDialog(existing: EventItem?, onDismiss: () -> Unit, onSave: (EventItem) -> Unit) {
    val base = existing ?: EventItem(title = "", date = LocalDate.now().toString(), startTime = "09:00", endTime = "10:00")
    var title by remember(existing?.id) { mutableStateOf(base.title) }
    var date by remember(existing?.id) { mutableStateOf(base.date) }
    var start by remember(existing?.id) { mutableStateOf(base.startTime) }
    var end by remember(existing?.id) { mutableStateOf(base.endTime) }
    var location by remember(existing?.id) { mutableStateOf(base.location) }
    var notes by remember(existing?.id) { mutableStateOf(base.notes) }
    var repeat by remember(existing?.id) { mutableStateOf(base.repeat) }
    var alerts by remember(existing?.id) { mutableStateOf(base.alerts) }
    var more by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Nuevo evento" else "Editar evento") }, text = {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 560.dp)) {
            item { OutlinedTextField(title, { title = it }, label = { Text("Evento") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { DateField("Fecha", date, false) { date = it ?: date } }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { TimeField("Inicio", start, false) { start = it ?: start } }; Box(Modifier.weight(1f)) { TimeField("Fin", end, false) { end = it ?: end } } } }
            item { TextButton(onClick = { more = !more }) { Text(if (more) "Menos opciones" else "Más opciones") } }
            if (more) {
                item { OutlinedTextField(location, { location = it }, label = { Text("Lugar") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
                item { RepeatEditor(repeat) { repeat = it } }
                item { AlertsEditor(alerts) { alerts = it } }
            }
        }
    }, confirmButton = { Button(enabled = title.isNotBlank(), onClick = { onSave(base.copy(title = title.trim(), date = date, startTime = start, endTime = end, location = location, notes = notes, repeat = repeat, alerts = alerts)) }) { Text("Guardar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
private fun ReminderEditDialog(existing: ReminderItem?, onDismiss: () -> Unit, onSave: (ReminderItem) -> Unit) {
    val base = existing ?: ReminderItem(title = "", date = LocalDate.now().toString(), time = "09:00")
    var title by remember(existing?.id) { mutableStateOf(base.title) }
    var date by remember(existing?.id) { mutableStateOf(base.date) }
    var time by remember(existing?.id) { mutableStateOf(base.time) }
    var notes by remember(existing?.id) { mutableStateOf(base.notes) }
    var repeat by remember(existing?.id) { mutableStateOf(base.repeat) }
    var repeatUntilDone by remember(existing?.id) { mutableStateOf(base.repeatUntilDone) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Nuevo recordatorio" else "Editar recordatorio") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Recordatorio") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            DateField("Fecha", date, false) { date = it ?: date }
            TimeField("Hora", time, false) { time = it ?: time }
            OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            RepeatEditor(repeat) { repeat = it }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(repeatUntilDone, { repeatUntilDone = it }); Text("Insistir hasta marcarlo como atendido") }
        }
    }, confirmButton = { Button(enabled = title.isNotBlank(), onClick = { onSave(base.copy(title = title.trim(), date = date, time = time, notes = notes, repeat = repeat, repeatUntilDone = repeatUntilDone, snoozedUntilMillis = null)) }) { Text("Guardar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
private fun DateField(label: String, value: String?, allowNone: Boolean, onChange: (String?) -> Unit) {
    val context = LocalContext.current
    val current = value?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: LocalDate.now()
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = {
                DatePickerDialog(context, { _, y, m, d -> onChange(LocalDate.of(y, m + 1, d).toString()) }, current.year, current.monthValue - 1, current.dayOfMonth).show()
            }) { Text(value ?: "Sin fecha") }
            if (allowNone && value != null) TextButton(onClick = { onChange(null) }) { Text("Quitar") }
        }
    }
}

@Composable
private fun TimeField(label: String, value: String?, allowNone: Boolean, onChange: (String?) -> Unit) {
    val context = LocalContext.current
    val current = value?.let { runCatching { LocalTime.parse(it) }.getOrNull() } ?: LocalTime.now()
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = {
                TimePickerDialog(context, { _, h, m -> onChange(LocalTime.of(h, m).toString()) }, current.hour, current.minute, true).show()
            }) { Text(value ?: "Sin hora") }
            if (allowNone && value != null) TextButton(onClick = { onChange(null) }) { Text("Quitar") }
        }
    }
}

@Composable
private fun RepeatEditor(value: RepeatRule, onChange: (RepeatRule) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var interval by remember(value.interval) { mutableStateOf(value.interval.toString()) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Repetición", style = MaterialTheme.typography.labelMedium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box {
                OutlinedButton(onClick = { menu = true }) { Text(repeatLabel(value.unit)) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    RepeatUnit.entries.forEach { unit -> DropdownMenuItem(text = { Text(repeatLabel(unit)) }, onClick = { menu = false; onChange(value.copy(unit = unit)) }) }
                }
            }
            if (value.unit != RepeatUnit.NONE) {
                OutlinedTextField(interval, { s -> interval = s.filter(Char::isDigit).take(4); onChange(value.copy(interval = interval.toIntOrNull()?.coerceAtLeast(1) ?: 1)) }, label = { Text("Cada") }, modifier = Modifier.width(100.dp), singleLine = true)
            }
        }
    }
}

private fun repeatLabel(unit: RepeatUnit) = when (unit) {
    RepeatUnit.NONE -> "No repetir"
    RepeatUnit.MINUTES -> "Minutos"
    RepeatUnit.HOURS -> "Horas"
    RepeatUnit.DAYS -> "Días"
    RepeatUnit.WEEKS -> "Semanas"
    RepeatUnit.MONTHS -> "Meses"
    RepeatUnit.YEARS -> "Años"
}

@Composable
private fun AlertsEditor(value: List<Int>, onChange: (List<Int>) -> Unit) {
    var custom by remember { mutableStateOf("") }
    val presets = listOf(0 to "A la hora", 5 to "5 min", 15 to "15 min", 30 to "30 min", 60 to "1 h", 1440 to "1 día")
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Avisos de esta tarea/evento", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
            presets.take(3).forEach { (min, label) -> FilterChip(selected = min in value, onClick = { onChange(if (min in value) value - min else (value + min).distinct().sorted()) }, label = { Text(label) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
            presets.drop(3).forEach { (min, label) -> FilterChip(selected = min in value, onClick = { onChange(if (min in value) value - min else (value + min).distinct().sorted()) }, label = { Text(label) }) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(custom, { custom = it.filter(Char::isDigit).take(5) }, label = { Text("Minutos antes") }, modifier = Modifier.width(150.dp), singleLine = true)
            Button(onClick = { custom.toIntOrNull()?.let { onChange((value + it).distinct().sorted()); custom = "" } }, enabled = custom.toIntOrNull() != null) { Text("Añadir") }
        }
    }
}

@Composable
private fun FreeSlotEditDialog(slot: TimeSlot, onDismiss: () -> Unit, onSave: (TimeSlot) -> Unit) {
    var start by remember(slot.startMinutes) { mutableStateOf(minutesToTime(slot.startMinutes).toString()) }
    var end by remember(slot.endMinutes) { mutableStateOf(minutesToTime(slot.endMinutes).toString()) }
    val startMin = runCatching { LocalTime.parse(start).toMinutes() }.getOrNull()
    val endMin = runCatching { LocalTime.parse(end).toMinutes() }.getOrNull()
    val valid = startMin != null && endMin != null && endMin - startMin >= 15
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar franja libre") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Puedes recortar o ampliar esta franja. Si luego quieres volver al cálculo según eventos y tareas, usa ‘Volver a franjas automáticas’.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TimeField("Desde", start, false) { start = it ?: start }
                TimeField("Hasta", end, false) { end = it ?: end }
                if (!valid) Text("La franja debe durar al menos 15 minutos.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { Button(enabled = valid, onClick = { onSave(TimeSlot(startMin!!, endMin!!)) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun SlotPickerDialog(task: TaskItem, state: AppState, onDismiss: () -> Unit, onSave: (TaskItem) -> Unit) {
    val today = LocalDate.now()
    val slots = freeSlotsForDay(state.copy(tasks = state.tasks.filterNot { it.id == task.id }), today)
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Mover a una franja libre") }, text = {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.heightIn(max = 420.dp)) {
            items(slots) { slot ->
                OutlinedButton(onClick = { onSave(task.copy(doDate = today.toString(), startTime = minutesToTime(slot.startMinutes).toString(), durationMinutes = minOf(task.durationMinutes ?: 30, slot.endMinutes - slot.startMinutes))) }, modifier = Modifier.fillMaxWidth()) {
                    Text("${minutesToTime(slot.startMinutes)} – ${minutesToTime(slot.endMinutes)}")
                }
            }
            if (slots.isEmpty()) item { Text("No quedan huecos libres entre 7:00 y 22:00.") }
        }
    }, confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}
