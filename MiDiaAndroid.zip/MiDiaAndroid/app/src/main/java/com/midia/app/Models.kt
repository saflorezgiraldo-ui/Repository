package com.midia.app

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.temporal.ChronoUnit
import java.util.UUID

enum class RepeatUnit { NONE, MINUTES, HOURS, DAYS, WEEKS, MONTHS, YEARS }
enum class Priority { LOW, MEDIUM, HIGH, URGENT }
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class AccentColor { GREEN, BLUE, PURPLE, ORANGE, ROSE }

data class RepeatRule(
    val unit: RepeatUnit = RepeatUnit.NONE,
    val interval: Int = 1
)

data class SubTask(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val completed: Boolean = false
)

data class TaskItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val notes: String = "",
    val category: String = "",
    val priority: Priority = Priority.MEDIUM,
    val subtasks: List<SubTask> = emptyList(),
    val doDate: String? = null,
    val dueDate: String? = null,
    val startTime: String? = null,
    val durationMinutes: Int? = null,
    val completed: Boolean = false,
    val repeat: RepeatRule = RepeatRule(),
    val alerts: List<Int> = emptyList()
)

data class EventItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val startTime: String,
    val endTime: String,
    val notes: String = "",
    val location: String = "",
    val done: Boolean = false,
    val repeat: RepeatRule = RepeatRule(),
    val alerts: List<Int> = emptyList()
)

data class ReminderItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val time: String,
    val notes: String = "",
    val done: Boolean = false,
    val repeat: RepeatRule = RepeatRule(),
    val repeatUntilDone: Boolean = false,
    val snoozedUntilMillis: Long? = null,
    val alerts: List<Int> = emptyList()
)

// Se conserva para poder leer datos creados por la v0.2 sin perderlos.
data class FreeSlotOverride(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val startMinutes: Int,
    val endMinutes: Int
)

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accentColor: AccentColor = AccentColor.GREEN
)

data class AppState(
    val tasks: List<TaskItem> = emptyList(),
    val events: List<EventItem> = emptyList(),
    val reminders: List<ReminderItem> = emptyList(),
    val freeSlotOverrides: List<FreeSlotOverride> = emptyList(),
    val settings: AppSettings = AppSettings()
)

data class TimeSlot(val startMinutes: Int, val endMinutes: Int)

data class DayTimeStats(
    val freeMinutes: Int,
    val busyMinutes: Int,
    val taskMinutes: Int,
    val eventMinutes: Int,
    val reminderCount: Int
)

fun LocalTime.toMinutes(): Int = hour * 60 + minute

fun occursOn(baseDate: String, rule: RepeatRule, target: LocalDate): Boolean {
    val base = runCatching { LocalDate.parse(baseDate) }.getOrNull() ?: return false
    if (target.isBefore(base)) return false
    if (target == base) return true
    val n = rule.interval.coerceAtLeast(1)
    return when (rule.unit) {
        RepeatUnit.NONE -> false
        RepeatUnit.MINUTES, RepeatUnit.HOURS -> true
        RepeatUnit.DAYS -> ChronoUnit.DAYS.between(base, target) % n == 0L
        RepeatUnit.WEEKS -> ChronoUnit.WEEKS.between(base, target) % n == 0L && target.dayOfWeek == base.dayOfWeek
        RepeatUnit.MONTHS -> {
            val months = ChronoUnit.MONTHS.between(base.withDayOfMonth(1), target.withDayOfMonth(1))
            months % n == 0L && target.dayOfMonth == base.dayOfMonth.coerceAtMost(target.lengthOfMonth())
        }
        RepeatUnit.YEARS -> {
            val years = ChronoUnit.YEARS.between(base, target)
            years % n == 0L && target.month == base.month && target.dayOfMonth == base.dayOfMonth.coerceAtMost(target.lengthOfMonth())
        }
    }
}

fun nextOccurrence(fromMillis: Long, rule: RepeatRule, repeatUntilDone: Boolean = false): Long? {
    val base = java.time.Instant.ofEpochMilli(fromMillis).atZone(java.time.ZoneId.systemDefault())
    val n = rule.interval.coerceAtLeast(1).toLong()
    val next = when (rule.unit) {
        RepeatUnit.NONE -> if (repeatUntilDone) base.plusMinutes(15) else return null
        RepeatUnit.MINUTES -> base.plusMinutes(n)
        RepeatUnit.HOURS -> base.plusHours(n)
        RepeatUnit.DAYS -> base.plusDays(n)
        RepeatUnit.WEEKS -> base.plusWeeks(n)
        RepeatUnit.MONTHS -> base.plusMonths(n)
        RepeatUnit.YEARS -> base.plusYears(n)
    }
    return next.toInstant().toEpochMilli()
}

/**
 * Estimación del día completo (00:00–24:00). Solo las tareas que tienen hora
 * reservan tiempo. Los recordatorios reservan 5 minutos simbólicos para que
 * también se reflejen en la lectura del día.
 */
fun dayTimeStats(state: AppState, date: LocalDate): DayTimeStats {
    val window = TimeSlot(0, 24 * 60)
    val eventSlots = state.events.filter { !it.done && occursOn(it.date, it.repeat, date) }.mapNotNull { e ->
        val start = runCatching { LocalTime.parse(e.startTime).toMinutes() }.getOrNull() ?: return@mapNotNull null
        val end = runCatching { LocalTime.parse(e.endTime).toMinutes() }.getOrNull() ?: (start + 60)
        TimeSlot(start, maxOf(end, start + 5))
    }
    val taskSlots = state.tasks.filter {
        !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, date) && it.startTime != null
    }.mapNotNull { t ->
        val start = runCatching { LocalTime.parse(t.startTime).toMinutes() }.getOrNull() ?: return@mapNotNull null
        TimeSlot(start, start + (t.durationMinutes ?: 30).coerceAtLeast(5))
    }
    val reminderSlots = state.reminders.filter { !it.done && occursOn(it.date, it.repeat, date) }.mapNotNull { r ->
        val start = runCatching { LocalTime.parse(r.time).toMinutes() }.getOrNull() ?: return@mapNotNull null
        TimeSlot(start, start + 5)
    }

    val busy = mergeSlots((eventSlots + taskSlots + reminderSlots).mapNotNull { clipSlot(it, window) })
    val busyMinutes = busy.sumOf { it.endMinutes - it.startMinutes }.coerceIn(0, 24 * 60)
    val eventMinutes = eventSlots.mapNotNull { clipSlot(it, window) }.sumOf { it.endMinutes - it.startMinutes }
    val taskMinutes = taskSlots.mapNotNull { clipSlot(it, window) }.sumOf { it.endMinutes - it.startMinutes }

    return DayTimeStats(
        freeMinutes = 24 * 60 - busyMinutes,
        busyMinutes = busyMinutes,
        taskMinutes = taskMinutes,
        eventMinutes = eventMinutes,
        reminderCount = reminderSlots.size
    )
}

private fun clipSlot(slot: TimeSlot, window: TimeSlot): TimeSlot? {
    val start = maxOf(slot.startMinutes, window.startMinutes)
    val end = minOf(slot.endMinutes, window.endMinutes)
    return if (end > start) TimeSlot(start, end) else null
}

private fun mergeSlots(slots: List<TimeSlot>): List<TimeSlot> =
    slots.sortedBy { it.startMinutes }.fold(mutableListOf()) { acc, slot ->
        if (slot.endMinutes <= slot.startMinutes) return@fold acc
        if (acc.isEmpty() || slot.startMinutes > acc.last().endMinutes) acc += slot
        else acc[acc.lastIndex] = TimeSlot(acc.last().startMinutes, maxOf(acc.last().endMinutes, slot.endMinutes))
        acc
    }

fun formatDuration(minutes: Int): String {
    val safe = minutes.coerceAtLeast(0)
    val h = safe / 60
    val m = safe % 60
    return when {
        h > 0 && m > 0 -> "${h} h ${m} min"
        h > 0 -> "${h} h"
        else -> "${m} min"
    }
}

fun taskDateTime(task: TaskItem): LocalDateTime? {
    val date = task.doDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: return null
    val time = task.startTime?.let { runCatching { LocalTime.parse(it) }.getOrNull() } ?: LocalTime.of(9, 0)
    return LocalDateTime.of(date, time)
}

fun eventDateTime(event: EventItem): LocalDateTime? = runCatching {
    LocalDateTime.of(LocalDate.parse(event.date), LocalTime.parse(event.startTime))
}.getOrNull()

fun reminderDateTime(reminder: ReminderItem): LocalDateTime? = runCatching {
    LocalDateTime.of(LocalDate.parse(reminder.date), LocalTime.parse(reminder.time))
}.getOrNull()
