package com.midia.app

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.temporal.ChronoUnit
import java.util.UUID

enum class RepeatUnit { NONE, MINUTES, HOURS, DAYS, WEEKS, MONTHS, YEARS }

data class RepeatRule(
    val unit: RepeatUnit = RepeatUnit.NONE,
    val interval: Int = 1
)

data class TaskItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val notes: String = "",
    val category: String = "",
    val doDate: String? = null,
    val dueDate: String? = null,
    val startTime: String? = null,
    val durationMinutes: Int? = null,
    val completed: Boolean = false,
    val repeat: RepeatRule = RepeatRule(),
    val alerts: List<Int> = emptyList()
)

data class EventItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val startTime: String,
    val endTime: String,
    val notes: String = "",
    val location: String = "",
    val done: Boolean = false,
    val repeat: RepeatRule = RepeatRule(),
    val alerts: List<Int> = emptyList()
)

data class ReminderItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val time: String,
    val notes: String = "",
    val done: Boolean = false,
    val repeat: RepeatRule = RepeatRule(),
    val repeatUntilDone: Boolean = false,
    val snoozedUntilMillis: Long? = null
)

data class FreeSlotOverride(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val startMinutes: Int,
    val endMinutes: Int
)

data class AppState(
    val tasks: List<TaskItem> = emptyList(),
    val events: List<EventItem> = emptyList(),
    val reminders: List<ReminderItem> = emptyList(),
    val freeSlotOverrides: List<FreeSlotOverride> = emptyList()
)

data class TimeSlot(val startMinutes: Int, val endMinutes: Int)

fun LocalTime.toMinutes(): Int = hour * 60 + minute
fun minutesToTime(total: Int): LocalTime = LocalTime.of((total / 60).coerceIn(0, 23), (total % 60).coerceIn(0, 59))

fun occursOn(baseDate: String, rule: RepeatRule, target: LocalDate): Boolean {
    val base = runCatching { LocalDate.parse(baseDate) }.getOrNull() ?: return false
    if (target.isBefore(base)) return false
    if (target == base) return true
    val n = rule.interval.coerceAtLeast(1)
    return when (rule.unit) {
        RepeatUnit.NONE -> false
        RepeatUnit.MINUTES, RepeatUnit.HOURS -> true
        RepeatUnit.DAYS -> ChronoUnit.DAYS.between(base, target) % n == 0L
        RepeatUnit.WEEKS -> ChronoUnit.WEEKS.between(base, target) % n == 0L && target.dayOfWeek == base.dayOfWeek
        RepeatUnit.MONTHS -> {
            val months = ChronoUnit.MONTHS.between(base.withDayOfMonth(1), target.withDayOfMonth(1))
            months % n == 0L && target.dayOfMonth == base.dayOfMonth.coerceAtMost(target.lengthOfMonth())
        }
        RepeatUnit.YEARS -> {
            val years = ChronoUnit.YEARS.between(base, target)
            years % n == 0L && target.month == base.month && target.dayOfMonth == base.dayOfMonth.coerceAtMost(target.lengthOfMonth())
        }
    }
}

fun nextOccurrence(fromMillis: Long, rule: RepeatRule, repeatUntilDone: Boolean = false): Long? {
    val base = java.time.Instant.ofEpochMilli(fromMillis).atZone(java.time.ZoneId.systemDefault())
    val n = rule.interval.coerceAtLeast(1).toLong()
    val next = when (rule.unit) {
        RepeatUnit.NONE -> if (repeatUntilDone) base.plusMinutes(15) else return null
        RepeatUnit.MINUTES -> base.plusMinutes(n)
        RepeatUnit.HOURS -> base.plusHours(n)
        RepeatUnit.DAYS -> base.plusDays(n)
        RepeatUnit.WEEKS -> base.plusWeeks(n)
        RepeatUnit.MONTHS -> base.plusMonths(n)
        RepeatUnit.YEARS -> base.plusYears(n)
    }
    return next.toInstant().toEpochMilli()
}

fun freeSlotsForDay(state: AppState, date: LocalDate, dayStart: Int = 7 * 60, dayEnd: Int = 22 * 60): List<TimeSlot> {
    val busy = mutableListOf<TimeSlot>()
    state.events.filter { !it.done && occursOn(it.date, it.repeat, date) }.forEach { e ->
        val s = runCatching { LocalTime.parse(e.startTime).toMinutes() }.getOrNull() ?: return@forEach
        val en = runCatching { LocalTime.parse(e.endTime).toMinutes() }.getOrNull() ?: (s + 60)
        busy += TimeSlot(s, maxOf(en, s + 15))
    }
    state.tasks.filter { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, date) && it.startTime != null }.forEach { t ->
        val s = runCatching { LocalTime.parse(t.startTime).toMinutes() }.getOrNull() ?: return@forEach
        busy += TimeSlot(s, s + (t.durationMinutes ?: 30))
    }

    val manualWindows = state.freeSlotOverrides
        .filter { it.date == date.toString() }
        .map { TimeSlot(it.startMinutes.coerceIn(0, 1439), it.endMinutes.coerceIn(1, 1440)) }
        .filter { it.endMinutes - it.startMinutes >= 15 }

    val windows = mergeSlots(
        if (manualWindows.isNotEmpty()) manualWindows
        else listOf(TimeSlot(dayStart.coerceIn(0, 1439), dayEnd.coerceIn(1, 1440)))
    )
    val mergedBusy = mergeSlots(busy)

    return windows.flatMap { window ->
        subtractBusy(window, mergedBusy)
    }.filter { it.endMinutes - it.startMinutes >= 15 }
}

private fun mergeSlots(slots: List<TimeSlot>): List<TimeSlot> =
    slots.sortedBy { it.startMinutes }.fold(mutableListOf()) { acc, slot ->
        if (slot.endMinutes <= slot.startMinutes) return@fold acc
        if (acc.isEmpty() || slot.startMinutes > acc.last().endMinutes) acc += slot
        else acc[acc.lastIndex] = TimeSlot(acc.last().startMinutes, maxOf(acc.last().endMinutes, slot.endMinutes))
        acc
    }

private fun subtractBusy(window: TimeSlot, busy: List<TimeSlot>): List<TimeSlot> {
    val out = mutableListOf<TimeSlot>()
    var cursor = window.startMinutes
    busy.forEach { block ->
        if (block.endMinutes <= window.startMinutes || block.startMinutes >= window.endMinutes) return@forEach
        val start = maxOf(block.startMinutes, window.startMinutes)
        val end = minOf(block.endMinutes, window.endMinutes)
        if (start > cursor) out += TimeSlot(cursor, start)
        cursor = maxOf(cursor, end)
    }
    if (cursor < window.endMinutes) out += TimeSlot(cursor, window.endMinutes)
    return out
}

fun taskDateTime(task: TaskItem): LocalDateTime? {
    val date = task.doDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: return null
    val time = task.startTime?.let { runCatching { LocalTime.parse(it) }.getOrNull() } ?: LocalTime.of(9, 0)
    return LocalDateTime.of(date, time)
}

fun eventDateTime(event: EventItem): LocalDateTime? = runCatching {
    LocalDateTime.of(LocalDate.parse(event.date), LocalTime.parse(event.startTime))
}.getOrNull()

fun reminderDateTime(reminder: ReminderItem): LocalDateTime? = runCatching {
    LocalDateTime.of(LocalDate.parse(reminder.date), LocalTime.parse(reminder.time))
}.getOrNull()
