package com.midia.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationScheduler.createChannel(this)
        setContent { MiDiaApp() }
    }
}

enum class AppTab(val shortLabel: String, val title: String) {
    TODAY("Hoy", "Mi Día"), UPCOMING("Próx.", "Próximos"), CALENDAR("Calend.", "Calendario"),
    INBOX("Sin fecha", "Sin fecha"), COMPLETED("Hechas", "Completadas")
}
enum class NewType { TASK, EVENT, REMINDER, BIRTHDAY }
enum class TodaySection { TASKS, EVENTS, REMINDERS }
data class TaskFilter(val priority: Priority? = null, val category: String? = null)

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun MiDiaApp() {
    val context = LocalContext.current
    val store = remember { AppStore(context.applicationContext) }
    var tab by remember { mutableStateOf(AppTab.TODAY) }
    var settingsOpen by remember { mutableStateOf(false) }
    var chooser by remember { mutableStateOf(false) }
    var taskEdit by remember { mutableStateOf<TaskItem?>(null) }
    var taskDialogOpen by remember { mutableStateOf(false) }
    var eventEdit by remember { mutableStateOf<EventItem?>(null) }
    var eventDialogOpen by remember { mutableStateOf(false) }
    var reminderEdit by remember { mutableStateOf<ReminderItem?>(null) }
    var reminderDialogOpen by remember { mutableStateOf(false) }
    var birthdayEdit by remember { mutableStateOf<BirthdayItem?>(null) }
    var birthdayDialogOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { NotificationScheduler.rescheduleAll(context, store.state) }

    val dark = when (store.state.settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val scheme = remember(dark, store.state.settings.accentColor) { appColorScheme(dark, store.state.settings.accentColor) }

    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text(if (settingsOpen) "Ajustes" else tab.title) },
                    navigationIcon = { if (settingsOpen) IconButton(onClick = { settingsOpen = false }) { Icon(Icons.Default.ArrowBack, "Volver") } },
                    actions = { if (!settingsOpen) IconButton(onClick = { settingsOpen = true }) { Icon(Icons.Default.Settings, "Ajustes") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface, titleContentColor = MaterialTheme.colorScheme.onSurface)
                )
            },
            floatingActionButton = { if (!settingsOpen) FloatingActionButton(onClick = { chooser = true }) { Icon(Icons.Default.Add, "Añadir") } },
            bottomBar = {
                if (!settingsOpen) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    val icons = mapOf(AppTab.TODAY to Icons.Default.Today, AppTab.UPCOMING to Icons.Default.DateRange, AppTab.CALENDAR to Icons.Default.CalendarMonth, AppTab.INBOX to Icons.Default.Inbox, AppTab.COMPLETED to Icons.Default.DoneAll)
                    AppTab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item, onClick = { tab = item }, icon = { Icon(icons.getValue(item), item.title) },
                            label = { Text(item.shortLabel, fontSize = 9.sp, maxLines = 1, fontWeight = if (tab == item) FontWeight.Bold else FontWeight.Normal) }, alwaysShowLabel = true
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                if (settingsOpen) SettingsScreen(store) else when (tab) {
                    AppTab.TODAY -> TodayScreen(store.state,
                        { taskEdit = it; taskDialogOpen = true }, { eventEdit = it; eventDialogOpen = true }, { reminderEdit = it; reminderDialogOpen = true }, { birthdayEdit = it; birthdayDialogOpen = true },
                        store::replaceTask, store::replaceEvent, store::replaceReminder, store::deleteTask, store::deleteEvent, store::deleteReminder, store::deleteBirthday)
                    AppTab.UPCOMING -> UpcomingScreen(store.state, store::replaceTask, { taskEdit = it; taskDialogOpen = true }, { eventEdit = it; eventDialogOpen = true }, { reminderEdit = it; reminderDialogOpen = true }, { birthdayEdit = it; birthdayDialogOpen = true })
                    AppTab.CALENDAR -> CalendarScreen(store.state, store::replaceTask, { taskEdit = it; taskDialogOpen = true }, { eventEdit = it; eventDialogOpen = true }, { reminderEdit = it; reminderDialogOpen = true }, { birthdayEdit = it; birthdayDialogOpen = true })
                    AppTab.INBOX -> InboxScreen(store.state, store::replaceTask, { taskEdit = it; taskDialogOpen = true }, store::deleteTask)
                    AppTab.COMPLETED -> CompletedScreen(store.state, store::replaceTask, store::replaceEvent, store::replaceReminder, { taskEdit = it; taskDialogOpen = true }, { eventEdit = it; eventDialogOpen = true }, { reminderEdit = it; reminderDialogOpen = true }, store::deleteTask, store::deleteEvent, store::deleteReminder)
                }
            }
        }

        if (chooser) TypeChooser(onDismiss = { chooser = false }) { type ->
            chooser = false
            when (type) {
                NewType.TASK -> { taskEdit = null; taskDialogOpen = true }
                NewType.EVENT -> { eventEdit = null; eventDialogOpen = true }
                NewType.REMINDER -> { reminderEdit = null; reminderDialogOpen = true }
                NewType.BIRTHDAY -> { birthdayEdit = null; birthdayDialogOpen = true }
            }
        }
        if (taskDialogOpen) TaskEditDialog(taskEdit, { taskDialogOpen = false; taskEdit = null }) { item ->
            if (store.state.tasks.any { it.id == item.id }) store.replaceTask(item) else store.addTask(item); taskDialogOpen = false; taskEdit = null
        }
        if (eventDialogOpen) EventEditDialog(eventEdit, { eventDialogOpen = false; eventEdit = null }) { item ->
            if (store.state.events.any { it.id == item.id }) store.replaceEvent(item) else store.addEvent(item); eventDialogOpen = false; eventEdit = null
        }
        if (reminderDialogOpen) ReminderEditDialog(reminderEdit, { reminderDialogOpen = false; reminderEdit = null }) { item ->
            if (store.state.reminders.any { it.id == item.id }) store.replaceReminder(item) else store.addReminder(item); reminderDialogOpen = false; reminderEdit = null
        }
        if (birthdayDialogOpen) BirthdayEditDialog(birthdayEdit, { birthdayDialogOpen = false; birthdayEdit = null }) { item ->
            if (store.state.birthdays.any { it.id == item.id }) store.replaceBirthday(item) else store.addBirthday(item); birthdayDialogOpen = false; birthdayEdit = null
        }
    }
}

private fun appColorScheme(dark: Boolean, accent: AccentColor): ColorScheme {
    val base = when (accent) {
        AccentColor.GREEN -> if (dark) Color(0xFF76E0C1) else Color(0xFF176B57)
        AccentColor.BLUE -> if (dark) Color(0xFF8AB4FF) else Color(0xFF285EA8)
        AccentColor.PURPLE -> if (dark) Color(0xFFC9A8FF) else Color(0xFF6742A6)
        AccentColor.ORANGE -> if (dark) Color(0xFFFFB86B) else Color(0xFF99571B)
        AccentColor.ROSE -> if (dark) Color(0xFFFF9DBD) else Color(0xFF984663)
        AccentColor.MONOCHROME -> if (dark) Color.White else Color(0xFF161616)
    }
    val container = when (accent) {
        AccentColor.GREEN -> if (dark) Color(0xFF12352D) else Color(0xFFD7F1E9)
        AccentColor.BLUE -> if (dark) Color(0xFF142A4A) else Color(0xFFDCE8FA)
        AccentColor.PURPLE -> if (dark) Color(0xFF2B1C46) else Color(0xFFE9DFFA)
        AccentColor.ORANGE -> if (dark) Color(0xFF42280F) else Color(0xFFF8E4D0)
        AccentColor.ROSE -> if (dark) Color(0xFF421B2A) else Color(0xFFF8DEE7)
        AccentColor.MONOCHROME -> if (dark) Color(0xFF1A1A1A) else Color(0xFFE8E8E8)
    }
    return if (dark) darkColorScheme(
        primary = base, onPrimary = if (accent == AccentColor.MONOCHROME) Color.Black else Color(0xFF071410), primaryContainer = container, onPrimaryContainer = Color.White,
        secondary = base, onSecondary = Color.Black, secondaryContainer = container, onSecondaryContainer = Color.White, tertiary = base,
        background = Color.Black, onBackground = Color(0xFFF4F4F4), surface = Color.Black, onSurface = Color(0xFFF4F4F4), surfaceVariant = Color(0xFF151515), onSurfaceVariant = Color(0xFFC9C9C9), outline = Color(0xFF555555)
    ) else lightColorScheme(
        primary = base, onPrimary = Color.White, primaryContainer = container, onPrimaryContainer = Color(0xFF101010), secondary = base, onSecondary = Color.White,
        secondaryContainer = container, onSecondaryContainer = Color(0xFF101010), tertiary = base, background = Color(0xFFF8F8F8), onBackground = Color(0xFF161616),
        surface = Color.White, onSurface = Color(0xFF161616), surfaceVariant = container.copy(alpha = 0.65f), onSurfaceVariant = Color(0xFF525252), outline = base.copy(alpha = 0.55f)
    )
}

@Composable
private fun TodayScreen(
    state: AppState,
    onEditTask: (TaskItem) -> Unit, onEditEvent: (EventItem) -> Unit, onEditReminder: (ReminderItem) -> Unit, onEditBirthday: (BirthdayItem) -> Unit,
    onTaskUpdate: (TaskItem) -> Unit, onEventUpdate: (EventItem) -> Unit, onReminderUpdate: (ReminderItem) -> Unit,
    onDeleteTask: (String) -> Unit, onDeleteEvent: (String) -> Unit, onDeleteReminder: (String) -> Unit, onDeleteBirthday: (String) -> Unit
) {
    val today = LocalDate.now()
    var section by remember { mutableStateOf(TodaySection.TASKS) }
    var filter by remember { mutableStateOf(TaskFilter()) }
    val allTasks = state.tasks.filter { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, today) }
    val categories = state.tasks.map { it.category.trim() }.filter { it.isNotBlank() }.distinct().sorted()
    val tasks = allTasks.filter { (filter.priority == null || it.priority == filter.priority) && (filter.category == null || it.category == filter.category) }
    val events = state.events.filter { !it.done && occursOn(it.date, it.repeat, today) }.sortedBy { it.startTime }
    val reminders = state.reminders.filter { !it.done && occursOn(it.date, it.repeat, today) }.sortedBy { it.time }
    val birthdays = state.birthdays.filter { birthdayOccursOn(it, today) }.sortedBy { it.time }
    val overdue = state.tasks.filter { !it.completed && it.doDate != null && runCatching { LocalDate.parse(it.doDate) }.getOrNull()?.isBefore(today) == true && it.repeat.unit == RepeatUnit.NONE }
        .filter { (filter.priority == null || it.priority == filter.priority) && (filter.category == null || it.category == filter.category) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(dateTitle(today), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                TodaySectionButton("Tareas", Icons.Default.CheckCircle, section == TodaySection.TASKS, Modifier.weight(1f)) { section = TodaySection.TASKS }
                TodaySectionButton("Eventos", Icons.Default.Event, section == TodaySection.EVENTS, Modifier.weight(1f)) { section = TodaySection.EVENTS }
                TodaySectionButton("Avisos", Icons.Default.Notifications, section == TodaySection.REMINDERS, Modifier.weight(1f)) { section = TodaySection.REMINDERS }
            }
        }
        item { DayStatsCard(dayTimeStats(state, today)) }
        when (section) {
            TodaySection.TASKS -> {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        SectionTitle("Tareas (${allTasks.size})")
                        TaskFilterButton(filter, categories) { filter = it }
                    }
                }
                if (tasks.isEmpty()) item { EmptyCard(if (allTasks.isEmpty()) "No tienes tareas para hoy." else "No hay tareas con estos filtros.") }
                items(tasks, key = { "task-${it.id}" }) { TaskCard(it, onEditTask, onTaskUpdate, onDeleteTask) }
                if (overdue.isNotEmpty()) {
                    item { SectionTitle("Pendientes anteriores") }
                    items(overdue, key = { "overdue-${it.id}" }) { TaskCard(it, onEditTask, onTaskUpdate, onDeleteTask) }
                }
            }
            TodaySection.EVENTS -> {
                item { SectionTitle("Eventos (${events.size})") }
                if (events.isEmpty()) item { EmptyCard("No tienes eventos hoy.") }
                items(events, key = { "event-${it.id}" }) { EventCard(it, onEditEvent, onEventUpdate, onDeleteEvent) }
            }
            TodaySection.REMINDERS -> {
                item { SectionTitle("Recordatorios y cumpleaños (${reminders.size + birthdays.size})") }
                if (reminders.isEmpty() && birthdays.isEmpty()) item { EmptyCard("No tienes recordatorios ni cumpleaños hoy.") }
                items(birthdays, key = { "birthday-${it.id}" }) { BirthdayCard(it, onEditBirthday, onDeleteBirthday) }
                items(reminders, key = { "rem-${it.id}" }) { ReminderCard(it, onEditReminder, onReminderUpdate, onDeleteReminder) }
            }
        }
    }
}

@Composable
private fun TodaySectionButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    if (selected) FilledTonalButton(onClick = onClick, modifier = modifier.heightIn(min = 52.dp)) { Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text(label, maxLines = 1) }
    else OutlinedButton(onClick = onClick, modifier = modifier.heightIn(min = 52.dp)) { Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text(label, maxLines = 1) }
}

@Composable
private fun DayStatsCard(stats: DayTimeStats) {
    val occupied = (stats.busyMinutes / 1440f).coerceIn(0f, 1f)
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("Tiempo libre estimado", style = MaterialTheme.typography.labelLarge); Text(formatDuration(stats.freeMinutes), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
                Icon(Icons.Default.QueryStats, "Estadística", tint = MaterialTheme.colorScheme.primary)
            }
            LinearProgressIndicator(progress = { occupied }, modifier = Modifier.fillMaxWidth())
            Text("Ocupado: ${formatDuration(stats.busyMinutes)}", style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                StatMini("Eventos", formatDuration(stats.eventMinutes), Modifier.weight(1f)); StatMini("Tareas", formatDuration(stats.taskMinutes), Modifier.weight(1f)); StatMini("Avisos", stats.reminderCount.toString(), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun StatMini(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .75f)) { Column(Modifier.padding(9.dp)) { Text(label, style = MaterialTheme.typography.labelSmall); Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold) } }
}

@Composable
private fun TaskFilterButton(value: TaskFilter, categories: List<String>, onChange: (TaskFilter) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val active = value.priority != null || value.category != null
    OutlinedButton(onClick = { open = true }) { Icon(Icons.Default.FilterList, null); Spacer(Modifier.width(5.dp)); Text(if (active) "Filtrar · activo" else "Filtrar") }
    if (open) AlertDialog(
        onDismissRequest = { open = false }, title = { Text("Filtrar tareas") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Prioridad", fontWeight = FontWeight.SemiBold)
                PriorityChips(value.priority) { onChange(value.copy(priority = it)) }
                Text("Categoría", fontWeight = FontWeight.SemiBold)
                if (categories.isEmpty()) Text("Todavía no hay categorías.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else FlowChips(listOf<String?>(null) + categories, value.category, { it ?: "Todas" }) { onChange(value.copy(category = it)) }
            }
        },
        confirmButton = { TextButton(onClick = { open = false }) { Text("Listo") } },
        dismissButton = { TextButton(onClick = { onChange(TaskFilter()); open = false }) { Text("Limpiar") } }
    )
}

@Composable
private fun PriorityChips(value: Priority?, onChange: (Priority?) -> Unit) {
    FlowChips(listOf<Priority?>(null, Priority.URGENT, Priority.HIGH, Priority.MEDIUM, Priority.LOW), value, { p -> if (p == null) "Todas" else priorityLabel(p) }, onChange)
}

@Composable
private fun <T> FlowChips(options: List<T>, selected: T, label: (T) -> String, onClick: (T) -> Unit) {
    options.chunked(3).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { row.forEach { option -> FilterChip(selected = option == selected, onClick = { onClick(option) }, label = { Text(label(option)) }) } }
    }
}

@Composable
private fun TaskCard(task: TaskItem, onEdit: (TaskItem) -> Unit, onUpdate: (TaskItem) -> Unit, onDelete: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var subDialog by remember { mutableStateOf(false) }
    var subEdit by remember { mutableStateOf<SubTask?>(null) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Checkbox(task.completed, { onUpdate(task.copy(completed = it)) })
                Column(Modifier.weight(1f).padding(top = 4.dp)) {
                    Text(task.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, textDecoration = if (task.completed) TextDecoration.LineThrough else null)
                    val meta = buildList { task.startTime?.let { add(it) }; task.durationMinutes?.let { add(formatDuration(it)) }; task.dueDate?.let { add("Entrega ${prettyDate(it)}") } }.joinToString(" · ")
                    if (meta.isNotBlank()) Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Opciones") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Editar") }, { menu = false; onEdit(task) }, leadingIcon = { Icon(Icons.Default.Edit, null) })
                        DropdownMenuItem({ Text("Añadir subtarea") }, { menu = false; subEdit = null; subDialog = true }, leadingIcon = { Icon(Icons.Default.AddTask, null) })
                        DropdownMenuItem({ Text("Hoy") }, { menu = false; onUpdate(task.copy(doDate = LocalDate.now().toString())) })
                        DropdownMenuItem({ Text("Mañana") }, { menu = false; onUpdate(task.copy(doDate = LocalDate.now().plusDays(1).toString())) })
                        DropdownMenuItem({ Text("Mover a Sin fecha") }, { menu = false; onUpdate(task.copy(doDate = null, startTime = null)) })
                        DropdownMenuItem({ Text("Eliminar") }, { menu = false; onDelete(task.id) }, leadingIcon = { Icon(Icons.Default.Delete, null) })
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                PriorityBadge(task.priority); if (task.category.isNotBlank()) SuggestionChip(onClick = {}, enabled = false, label = { Text(task.category) }); if (task.alerts.isNotEmpty()) Text("${task.alerts.size} avisos", style = MaterialTheme.typography.labelSmall)
            }
            if (task.subtasks.isNotEmpty()) {
                Text("Subtareas ${task.subtasks.count { it.completed }}/${task.subtasks.size}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                task.subtasks.forEach { sub ->
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(sub.completed, { checked -> onUpdate(task.copy(subtasks = task.subtasks.map { if (it.id == sub.id) it.copy(completed = checked) else it })) })
                            Column(Modifier.weight(1f)) { Text(sub.title, textDecoration = if (sub.completed) TextDecoration.LineThrough else null); if (sub.doDate != null || sub.startTime != null) Text(listOfNotNull(sub.doDate?.let(::prettyDate), sub.startTime).joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            IconButton(onClick = { subEdit = sub; subDialog = true }) { Icon(Icons.Default.Edit, "Editar subtarea") }
                        }
                    }
                }
            }
            TextButton(onClick = { subEdit = null; subDialog = true }) { Icon(Icons.Default.Add, null); Text("Agregar subtarea") }
        }
    }
    if (subDialog) SubTaskEditDialog(subEdit, { subDialog = false; subEdit = null }) { saved ->
        val newList = if (task.subtasks.any { it.id == saved.id }) task.subtasks.map { if (it.id == saved.id) saved else it } else task.subtasks + saved
        onUpdate(task.copy(subtasks = newList)); subDialog = false; subEdit = null
    }
}

@Composable
private fun PriorityBadge(priority: Priority) { SuggestionChip(onClick = {}, enabled = false, label = { Text(priorityLabel(priority)) }) }
private fun priorityLabel(p: Priority) = when (p) { Priority.LOW -> "Baja"; Priority.MEDIUM -> "Media"; Priority.HIGH -> "Alta"; Priority.URGENT -> "Urgente" }

@Composable
private fun EventCard(event: EventItem, onEdit: (EventItem) -> Unit, onUpdate: (EventItem) -> Unit, onDelete: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.width(62.dp)) { Text(event.startTime, fontWeight = FontWeight.Bold); Text(event.endTime, style = MaterialTheme.typography.bodySmall) }
        Column(Modifier.weight(1f)) { Text(event.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); if (event.location.isNotBlank()) Text(event.location, style = MaterialTheme.typography.bodySmall); if (event.category.isNotBlank()) Text(event.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary); if (event.alerts.isNotEmpty()) Text("${event.alerts.size} avisos", style = MaterialTheme.typography.labelSmall) }
        Box { IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "Opciones") }; DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem({ Text("Editar") }, { menu = false; onEdit(event) }); DropdownMenuItem({ Text(if (event.done) "Restaurar" else "Marcar realizado") }, { menu = false; onUpdate(event.copy(done = !event.done)) }); DropdownMenuItem({ Text("Eliminar") }, { menu = false; onDelete(event.id) })
        } }
    } }
}

@Composable
private fun ReminderCard(reminder: ReminderItem, onEdit: (ReminderItem) -> Unit, onUpdate: (ReminderItem) -> Unit, onDelete: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
        Icon(Icons.Default.Notifications, null, Modifier.padding(8.dp), tint = MaterialTheme.colorScheme.primary)
        Column(Modifier.weight(1f).padding(top = 5.dp)) { Text(reminder.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text(reminder.time + if (reminder.alerts.isNotEmpty()) " · ${reminder.alerts.size} avisos" else "", style = MaterialTheme.typography.bodySmall); if (reminder.category.isNotBlank()) Text(reminder.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary); if (reminder.repeatUntilDone) Text("Insiste hasta atender", style = MaterialTheme.typography.labelSmall) }
        Box { IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "Opciones") }; DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem({ Text("Editar") }, { menu = false; onEdit(reminder) }); listOf(5, 10, 15, 30, 60).forEach { mins -> DropdownMenuItem({ Text("Posponer $mins min") }, { menu = false; onUpdate(reminder.copy(snoozedUntilMillis = System.currentTimeMillis() + mins * 60_000L)) }) }; DropdownMenuItem({ Text(if (reminder.done) "Restaurar" else "Atendido") }, { menu = false; onUpdate(reminder.copy(done = !reminder.done)) }); DropdownMenuItem({ Text("Eliminar") }, { menu = false; onDelete(reminder.id) })
        } }
    } }
}

@Composable
private fun BirthdayCard(item: BirthdayItem, onEdit: (BirthdayItem) -> Unit, onDelete: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Cake, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(item.contactName, fontWeight = FontWeight.Bold); Text("Cumpleaños · ${item.time}", style = MaterialTheme.typography.bodySmall); if (item.alerts.isNotEmpty()) Text("${item.alerts.size} avisos", style = MaterialTheme.typography.labelSmall) }
        Box { IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "Opciones") }; DropdownMenu(menu, { menu = false }) { DropdownMenuItem({ Text("Editar") }, { menu = false; onEdit(item) }); DropdownMenuItem({ Text("Eliminar") }, { menu = false; onDelete(item.id) }) } }
    } }
}

@Composable
private fun UpcomingScreen(state: AppState, onTaskUpdate: (TaskItem) -> Unit, onEditTask: (TaskItem) -> Unit, onEditEvent: (EventItem) -> Unit, onEditReminder: (ReminderItem) -> Unit, onEditBirthday: (BirthdayItem) -> Unit) {
    var filter by remember { mutableStateOf(TaskFilter()) }
    val categories = state.tasks.map { it.category }.filter { it.isNotBlank() }.distinct().sorted()
    val start = LocalDate.now()
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TaskFilterButton(filter, categories) { filter = it } } }
        for (i in 0..6) {
            val date = start.plusDays(i.toLong())
            val tasks = state.tasks.filter { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, date) && (filter.priority == null || it.priority == filter.priority) && (filter.category == null || it.category == filter.category) }
            val events = state.events.filter { !it.done && occursOn(it.date, it.repeat, date) }
            val rems = state.reminders.filter { !it.done && occursOn(it.date, it.repeat, date) }
            val birthdays = state.birthdays.filter { birthdayOccursOn(it, date) }
            if (tasks.isNotEmpty() || events.isNotEmpty() || rems.isNotEmpty() || birthdays.isNotEmpty()) {
                item { SectionTitle(dateTitle(date)) }
                items(events, key = { "up-e-${date}-${it.id}" }) { EventCard(it, onEditEvent, { _ -> }, { _ -> }) }
                items(tasks, key = { "up-t-${date}-${it.id}" }) { TaskCard(it, onEditTask, onTaskUpdate, { _ -> }) }
                items(birthdays, key = { "up-b-${date}-${it.id}" }) { BirthdayCard(it, onEditBirthday, { _ -> }) }
                items(rems, key = { "up-r-${date}-${it.id}" }) { ReminderCard(it, onEditReminder, { _ -> }, { _ -> }) }
            }
        }
    }
}

@Composable
private fun CalendarScreen(state: AppState, onTaskUpdate: (TaskItem) -> Unit, onEditTask: (TaskItem) -> Unit, onEditEvent: (EventItem) -> Unit, onEditReminder: (ReminderItem) -> Unit, onEditBirthday: (BirthdayItem) -> Unit) {
    var month by remember { mutableStateOf(YearMonth.now()) }; var selected by remember { mutableStateOf(LocalDate.now()) }
    val first = month.atDay(1); val offset = (first.dayOfWeek.value - 1).coerceAtLeast(0); val rows = (List(offset) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }).chunked(7)
    val tasks = state.tasks.filter { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, selected) }; val events = state.events.filter { !it.done && occursOn(it.date, it.repeat, selected) }; val rems = state.reminders.filter { !it.done && occursOn(it.date, it.repeat, selected) }; val birthdays = state.birthdays.filter { birthdayOccursOn(it, selected) }
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton({ month = month.minusMonths(1); selected = month.atDay(1) }) { Icon(Icons.Default.ChevronLeft, "Mes anterior") }
            Text(month.month.getDisplayName(TextStyle.FULL, Locale("es", "CO")).replaceFirstChar { it.uppercase() } + " ${month.year}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            IconButton({ month = month.plusMonths(1); selected = month.atDay(1) }) { Icon(Icons.Default.ChevronRight, "Mes siguiente") }
        } }
        item { Row(Modifier.fillMaxWidth()) { listOf("L", "M", "X", "J", "V", "S", "D").forEach { Text(it, Modifier.weight(1f), style = MaterialTheme.typography.labelMedium) } } }
        items(rows) { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            (row + List(7 - row.size) { null }).forEach { date -> if (date == null) Spacer(Modifier.weight(1f).height(64.dp)) else {
                val isSelected = date == selected
                val count = state.tasks.count { !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, date) } + state.events.count { !it.done && occursOn(it.date, it.repeat, date) } + state.reminders.count { !it.done && occursOn(it.date, it.repeat, date) } + state.birthdays.count { birthdayOccursOn(it, date) }
                Surface(onClick = { selected = date }, modifier = Modifier.weight(1f).height(64.dp), shape = RoundedCornerShape(12.dp), color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .35f), border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null) {
                    Column(Modifier.padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text(date.dayOfMonth.toString(), fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium); Text(date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("es", "CO")).removeSuffix("."), style = MaterialTheme.typography.labelSmall, color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant); if (count > 0) Text("$count", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
                }
            } }
        } }
        item { Text(dateTitle(selected), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
        if (tasks.isEmpty() && events.isEmpty() && rems.isEmpty() && birthdays.isEmpty()) item { EmptyCard("No hay nada para este día.") }
        items(events, key = { "cal-e-${it.id}" }) { EventCard(it, onEditEvent, { _ -> }, { _ -> }) }; items(tasks, key = { "cal-t-${it.id}" }) { TaskCard(it, onEditTask, onTaskUpdate, { _ -> }) }; items(birthdays, key = { "cal-b-${it.id}" }) { BirthdayCard(it, onEditBirthday, { _ -> }) }; items(rems, key = { "cal-r-${it.id}" }) { ReminderCard(it, onEditReminder, { _ -> }, { _ -> }) }
    }
}

@Composable
private fun InboxScreen(state: AppState, onUpdate: (TaskItem) -> Unit, onEdit: (TaskItem) -> Unit, onDelete: (String) -> Unit) {
    var filter by remember { mutableStateOf(TaskFilter()) }; val all = state.tasks.filter { !it.completed && it.doDate == null }; val categories = all.map { it.category }.filter { it.isNotBlank() }.distinct().sorted(); val tasks = all.filter { (filter.priority == null || it.priority == filter.priority) && (filter.category == null || it.category == filter.category) }
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Tareas que sabes que tienes que hacer, pero todavía no tienen día.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TaskFilterButton(filter, categories) { filter = it } } }
        if (tasks.isEmpty()) item { EmptyCard(if (all.isEmpty()) "La bandeja está vacía." else "No hay tareas con estos filtros.") }; items(tasks, key = { it.id }) { TaskCard(it, onEdit, onUpdate, onDelete) }
    }
}

@Composable
private fun CompletedScreen(state: AppState, onTaskUpdate: (TaskItem) -> Unit, onEventUpdate: (EventItem) -> Unit, onReminderUpdate: (ReminderItem) -> Unit, onEditTask: (TaskItem) -> Unit, onEditEvent: (EventItem) -> Unit, onEditReminder: (ReminderItem) -> Unit, onDeleteTask: (String) -> Unit, onDeleteEvent: (String) -> Unit, onDeleteReminder: (String) -> Unit) {
    val tasks = state.tasks.filter { it.completed }; val events = state.events.filter { it.done }; val rems = state.reminders.filter { it.done }
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (tasks.isEmpty() && events.isEmpty() && rems.isEmpty()) item { EmptyCard("Todavía no has completado nada.") }
        if (tasks.isNotEmpty()) { item { SectionTitle("Tareas completadas") }; items(tasks, key = { "done-t-${it.id}" }) { TaskCard(it, onEditTask, onTaskUpdate, onDeleteTask) } }
        if (events.isNotEmpty()) { item { SectionTitle("Eventos realizados") }; items(events, key = { "done-e-${it.id}" }) { EventCard(it, onEditEvent, onEventUpdate, onDeleteEvent) } }
        if (rems.isNotEmpty()) { item { SectionTitle("Recordatorios atendidos") }; items(rems, key = { "done-r-${it.id}" }) { ReminderCard(it, onEditReminder, onReminderUpdate, onDeleteReminder) } }
    }
}

@Composable
private fun SettingsScreen(store: AppStore) {
    val context = LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { SectionTitle("Apariencia") }
        item { Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Modo", fontWeight = FontWeight.SemiBold); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { ThemeMode.entries.forEach { mode -> FilterChip(store.state.settings.themeMode == mode, { store.setThemeMode(mode) }, label = { Text(themeModeLabel(mode)) }) } }
            Text("Color de toda la interfaz", fontWeight = FontWeight.SemiBold); AccentColor.entries.forEach { color -> val selected = store.state.settings.accentColor == color; Surface(onClick = { store.setAccentColor(color) }, shape = RoundedCornerShape(14.dp), color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .4f)) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(26.dp), CircleShape, color = accentPreview(color)) {}; Spacer(Modifier.width(10.dp)); Text(accentLabel(color), Modifier.weight(1f)); if (selected) Icon(Icons.Default.Check, "Seleccionado", tint = MaterialTheme.colorScheme.primary) } } }
            if (store.state.settings.themeMode == ThemeMode.DARK) Text("Modo oscuro AMOLED: fondo negro puro.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } } }

        item { SectionTitle("Notificaciones") }
        item { Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            SettingsSwitch("Activar notificaciones", store.state.settings.notificationsEnabled, store::setNotificationsEnabled)
            SettingsSwitch("Tareas", store.state.settings.taskNotifications, store::setTaskNotifications)
            SettingsSwitch("Eventos", store.state.settings.eventNotifications, store::setEventNotifications)
            SettingsSwitch("Recordatorios", store.state.settings.reminderNotifications, store::setReminderNotifications)
            SettingsSwitch("Cumpleaños", store.state.settings.birthdayNotifications, store::setBirthdayNotifications)
            SettingsSwitch("Vibración", store.state.settings.notificationVibration, store::setNotificationVibration)
            Text("Cada tipo usa su propio símbolo en la notificación.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } } }
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) item { Button(onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Permitir notificaciones") } }
        item { OutlinedButton(onClick = { NotificationScheduler.showTest(context, store.state.settings.notificationVibration) }) { Text("Probar notificación") } }
        if (!NotificationScheduler.canExact(context)) item { Button(onClick = { NotificationScheduler.exactAlarmSettingsIntent(context)?.let { context.startActivity(it) } }) { Text("Permitir alarmas exactas") } }

        item { SectionTitle("Créditos") }
        item { Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("Mi Día", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text("Idea y dirección: Samuel Flórez"); Text("Diseño y decisiones de producto: Samuel Flórez"); Text("Desarrollo colaborativo: Samuel Flórez + ChatGPT (OpenAI)"); Text("Versión 0.4.0", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
    }
}

@Composable
private fun SettingsSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(checked, onChange) } }
private fun themeModeLabel(mode: ThemeMode) = when (mode) { ThemeMode.SYSTEM -> "Sistema"; ThemeMode.LIGHT -> "Día"; ThemeMode.DARK -> "Noche" }
private fun accentLabel(c: AccentColor) = when (c) { AccentColor.GREEN -> "Verde"; AccentColor.BLUE -> "Azul"; AccentColor.PURPLE -> "Morado"; AccentColor.ORANGE -> "Naranja"; AccentColor.ROSE -> "Rosa"; AccentColor.MONOCHROME -> "Monocromático" }
private fun accentPreview(c: AccentColor) = when (c) { AccentColor.GREEN -> Color(0xFF27A783); AccentColor.BLUE -> Color(0xFF4D82D6); AccentColor.PURPLE -> Color(0xFF8B62D4); AccentColor.ORANGE -> Color(0xFFD77B2A); AccentColor.ROSE -> Color(0xFFD6678A); AccentColor.MONOCHROME -> Color(0xFF555555) }

@Composable
private fun TypeChooser(onDismiss: () -> Unit, onChoose: (NewType) -> Unit) {
    var selected by remember { mutableStateOf<NewType?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("¿Qué quieres añadir?") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TypeOption("Tarea", Icons.Default.CheckCircle, selected == NewType.TASK) { selected = NewType.TASK }
        TypeOption("Evento", Icons.Default.Event, selected == NewType.EVENT) { selected = NewType.EVENT }
        TypeOption("Recordatorio", Icons.Default.Notifications, selected == NewType.REMINDER) { selected = NewType.REMINDER }
        TypeOption("Cumpleaños", Icons.Default.Cake, selected == NewType.BIRTHDAY) { selected = NewType.BIRTHDAY }
    } }, confirmButton = { Button(enabled = selected != null, onClick = { selected?.let(onChoose) }) { Text("Continuar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
private fun TypeOption(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(14.dp), color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f), border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null) { Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface); Spacer(Modifier.width(10.dp)); Text(label, Modifier.weight(1f), fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal); if (selected) Icon(Icons.Default.CheckCircle, "Seleccionado", tint = MaterialTheme.colorScheme.primary) } }
}

@Composable
private fun TaskEditDialog(existing: TaskItem?, onDismiss: () -> Unit, onSave: (TaskItem) -> Unit) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title ?: "") }; var notes by remember(existing?.id) { mutableStateOf(existing?.notes ?: "") }; var category by remember(existing?.id) { mutableStateOf(existing?.category ?: "") }; var priority by remember(existing?.id) { mutableStateOf(existing?.priority ?: Priority.MEDIUM) }; var doDate by remember(existing?.id) { mutableStateOf(existing?.doDate) }; var dueDate by remember(existing?.id) { mutableStateOf(existing?.dueDate) }; var time by remember(existing?.id) { mutableStateOf(existing?.startTime) }; var duration by remember(existing?.id) { mutableStateOf(existing?.durationMinutes?.toString() ?: "") }; var repeat by remember(existing?.id) { mutableStateOf(existing?.repeat ?: RepeatRule()) }; var alerts by remember(existing?.id) { mutableStateOf(existing?.alerts ?: emptyList()) }; var subtasks by remember(existing?.id) { mutableStateOf(existing?.subtasks ?: emptyList()) }
    EditorDialog(if (existing == null) "Nueva tarea" else "Editar tarea", onDismiss, title.isNotBlank(), { onSave(TaskItem(existing?.id ?: java.util.UUID.randomUUID().toString(), title.trim(), notes, category.trim(), priority, subtasks, doDate, dueDate, time, duration.toIntOrNull(), existing?.completed ?: false, repeat, alerts)) }) {
        OutlinedTextField(title, { title = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth(), singleLine = true); OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2); OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth(), singleLine = true); PriorityPicker(priority) { priority = it }; DateField("Fecha para hacerla", doDate, true) { doDate = it }; DateField("Fecha límite / entrega", dueDate, true) { dueDate = it }; TimeField("Hora opcional", time, true) { time = it }; OutlinedTextField(duration, { duration = it.filter(Char::isDigit).take(4) }, label = { Text("Duración (minutos)") }, modifier = Modifier.fillMaxWidth(), singleLine = true); RepeatEditor(repeat) { repeat = it }; AlertsEditor(alerts, "Avisos") { alerts = it }; SubTasksEditor(subtasks) { subtasks = it }
    }
}

@Composable
private fun SubTaskEditDialog(existing: SubTask?, onDismiss: () -> Unit, onSave: (SubTask) -> Unit) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title ?: "") }; var notes by remember(existing?.id) { mutableStateOf(existing?.notes ?: "") }; var category by remember(existing?.id) { mutableStateOf(existing?.category ?: "") }; var priority by remember(existing?.id) { mutableStateOf(existing?.priority ?: Priority.MEDIUM) }; var doDate by remember(existing?.id) { mutableStateOf(existing?.doDate) }; var dueDate by remember(existing?.id) { mutableStateOf(existing?.dueDate) }; var time by remember(existing?.id) { mutableStateOf(existing?.startTime) }; var duration by remember(existing?.id) { mutableStateOf(existing?.durationMinutes?.toString() ?: "") }; var repeat by remember(existing?.id) { mutableStateOf(existing?.repeat ?: RepeatRule()) }; var alerts by remember(existing?.id) { mutableStateOf(existing?.alerts ?: emptyList()) }
    EditorDialog(if (existing == null) "Nueva subtarea" else "Editar subtarea", onDismiss, title.isNotBlank(), { onSave(SubTask(existing?.id ?: java.util.UUID.randomUUID().toString(), title.trim(), notes, category.trim(), priority, doDate, dueDate, time, duration.toIntOrNull(), existing?.completed ?: false, repeat, alerts)) }) {
        Text("La subtarea tiene las mismas opciones principales de una tarea.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant); OutlinedTextField(title, { title = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth(), singleLine = true); OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2); OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth(), singleLine = true); PriorityPicker(priority) { priority = it }; DateField("Fecha para hacerla", doDate, true) { doDate = it }; DateField("Fecha límite", dueDate, true) { dueDate = it }; TimeField("Hora", time, true) { time = it }; OutlinedTextField(duration, { duration = it.filter(Char::isDigit).take(4) }, label = { Text("Duración (minutos)") }, modifier = Modifier.fillMaxWidth(), singleLine = true); RepeatEditor(repeat) { repeat = it }; AlertsEditor(alerts, "Avisos de la subtarea") { alerts = it }
    }
}

@Composable
private fun EventEditDialog(existing: EventItem?, onDismiss: () -> Unit, onSave: (EventItem) -> Unit) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title ?: "") }; var date by remember(existing?.id) { mutableStateOf<String?>(existing?.date) }; var start by remember(existing?.id) { mutableStateOf<String?>(existing?.startTime) }; var end by remember(existing?.id) { mutableStateOf<String?>(existing?.endTime) }; var notes by remember(existing?.id) { mutableStateOf(existing?.notes ?: "") }; var location by remember(existing?.id) { mutableStateOf(existing?.location ?: "") }; var category by remember(existing?.id) { mutableStateOf(existing?.category ?: "") }; var repeat by remember(existing?.id) { mutableStateOf(existing?.repeat ?: RepeatRule()) }; var alerts by remember(existing?.id) { mutableStateOf(existing?.alerts ?: emptyList()) }
    EditorDialog(if (existing == null) "Nuevo evento" else "Editar evento", onDismiss, title.isNotBlank() && date != null && start != null && end != null, { onSave(EventItem(existing?.id ?: java.util.UUID.randomUUID().toString(), title.trim(), date!!, start!!, end!!, notes, location, category.trim(), existing?.done ?: false, repeat, alerts)) }) {
        OutlinedTextField(title, { title = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth(), singleLine = true); OutlinedTextField(location, { location = it }, label = { Text("Lugar") }, modifier = Modifier.fillMaxWidth(), singleLine = true); OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth(), singleLine = true); DateField("Fecha", date, false) { date = it }; TimeField("Hora de inicio", start, false) { start = it }; TimeField("Hora de fin", end, false) { end = it }; OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2); RepeatEditor(repeat) { repeat = it }; AlertsEditor(alerts, "Avisos") { alerts = it }
    }
}

@Composable
private fun ReminderEditDialog(existing: ReminderItem?, onDismiss: () -> Unit, onSave: (ReminderItem) -> Unit) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title ?: "") }; var date by remember(existing?.id) { mutableStateOf<String?>(existing?.date) }; var time by remember(existing?.id) { mutableStateOf<String?>(existing?.time) }; var notes by remember(existing?.id) { mutableStateOf(existing?.notes ?: "") }; var category by remember(existing?.id) { mutableStateOf(existing?.category ?: "") }; var repeat by remember(existing?.id) { mutableStateOf(existing?.repeat ?: RepeatRule()) }; var untilDone by remember(existing?.id) { mutableStateOf(existing?.repeatUntilDone ?: false) }; var alerts by remember(existing?.id) { mutableStateOf(existing?.alerts ?: emptyList()) }
    EditorDialog(if (existing == null) "Nuevo recordatorio" else "Editar recordatorio", onDismiss, title.isNotBlank() && date != null && time != null, { onSave(ReminderItem(existing?.id ?: java.util.UUID.randomUUID().toString(), title.trim(), date!!, time!!, notes, category.trim(), existing?.done ?: false, repeat, untilDone, existing?.snoozedUntilMillis, alerts)) }) {
        OutlinedTextField(title, { title = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth(), singleLine = true); OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth(), singleLine = true); DateField("Fecha", date, false) { date = it }; TimeField("Hora", time, false) { time = it }; OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2); RepeatEditor(repeat) { repeat = it }; AlertsEditor(alerts, "Avisos adicionales") { alerts = it }; Row(verticalAlignment = Alignment.CenterVertically) { Switch(untilDone, { untilDone = it }); Spacer(Modifier.width(8.dp)); Text("Repetir hasta atender") }
    }
}

@Composable
private fun BirthdayEditDialog(existing: BirthdayItem?, onDismiss: () -> Unit, onSave: (BirthdayItem) -> Unit) {
    val context = LocalContext.current
    var contactName by remember(existing?.id) { mutableStateOf(existing?.contactName ?: "") }; var contactUri by remember(existing?.id) { mutableStateOf(existing?.contactUri) }; var date by remember(existing?.id) { mutableStateOf<String?>(existing?.birthDate) }; var time by remember(existing?.id) { mutableStateOf<String?>(existing?.time) }; var notes by remember(existing?.id) { mutableStateOf(existing?.notes ?: "") }; var alerts by remember(existing?.id) { mutableStateOf(existing?.alerts ?: listOf(0, 1440)) }
    val contactPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickContact()) { uri ->
        if (uri != null) {
            contactUri = uri.toString()
            runCatching { context.contentResolver.query(uri, arrayOf(ContactsContract.Contacts.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) contactName = c.getString(0).orEmpty() } }
        }
    }
    EditorDialog(if (existing == null) "Nuevo cumpleaños" else "Editar cumpleaños", onDismiss, contactName.isNotBlank() && date != null && time != null, { onSave(BirthdayItem(existing?.id ?: java.util.UUID.randomUUID().toString(), contactName.trim(), contactUri, date!!, time!!, notes, alerts)) }) {
        OutlinedButton(onClick = { contactPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Contacts, null); Spacer(Modifier.width(8.dp)); Text("Escoger contacto del teléfono") }
        if (contactName.isNotBlank()) Text("Contacto: $contactName", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
        OutlinedTextField(contactName, { contactName = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        DateField("Fecha de cumpleaños", date, false) { date = it }; TimeField("Hora del aviso", time, false) { time = it }; OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth(), minLines = 2); AlertsEditor(alerts, "Avisos del cumpleaños") { alerts = it }; Text("Se repetirá automáticamente cada año.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EditorDialog(title: String, onDismiss: () -> Unit, canSave: Boolean, onSave: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss) { Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface, tonalElevation = 6.dp) { Column(Modifier.fillMaxWidth().heightIn(max = 720.dp).padding(16.dp)) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Cerrar") } }; LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 8.dp)) { item { Column(verticalArrangement = Arrangement.spacedBy(12.dp), content = content) } }; Button(onClick = onSave, enabled = canSave, modifier = Modifier.fillMaxWidth()) { Text("Guardar") } } } }
}

@Composable
private fun PriorityPicker(value: Priority, onChange: (Priority) -> Unit) { Column(verticalArrangement = Arrangement.spacedBy(5.dp)) { Text("Prioridad", style = MaterialTheme.typography.labelMedium); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { Priority.entries.forEach { p -> FilterChip(p == value, { onChange(p) }, label = { Text(priorityLabel(p)) }) } } } }

@Composable
private fun SubTasksEditor(value: List<SubTask>, onChange: (List<SubTask>) -> Unit) {
    var dialog by remember { mutableStateOf(false) }; var editing by remember { mutableStateOf<SubTask?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text("Subtareas", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        value.forEach { sub -> Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .4f)) { Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) { Checkbox(sub.completed, { c -> onChange(value.map { if (it.id == sub.id) it.copy(completed = c) else it }) }); Column(Modifier.weight(1f)) { Text(sub.title); Text(priorityLabel(sub.priority) + if (sub.category.isNotBlank()) " · ${sub.category}" else "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; IconButton({ editing = sub; dialog = true }) { Icon(Icons.Default.Edit, "Editar") }; IconButton({ onChange(value.filterNot { it.id == sub.id }) }) { Icon(Icons.Default.Delete, "Eliminar") } } } }
        OutlinedButton(onClick = { editing = null; dialog = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AddTask, null); Spacer(Modifier.width(6.dp)); Text("Crear subtarea") }
    }
    if (dialog) SubTaskEditDialog(editing, { dialog = false; editing = null }) { saved -> onChange(if (value.any { it.id == saved.id }) value.map { if (it.id == saved.id) saved else it } else value + saved); dialog = false; editing = null }
}

@Composable
private fun DateField(label: String, value: String?, allowNone: Boolean, onChange: (String?) -> Unit) {
    val context = LocalContext.current; val current = value?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: LocalDate.now()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        OutlinedButton(onClick = { DatePickerDialog(context, { _, y, m, d -> onChange(LocalDate.of(y, m + 1, d).toString()) }, current.year, current.monthValue - 1, current.dayOfMonth).show() }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text("Seleccionar fecha") }
        if (value != null) Text("Elegida: ${prettyDateLong(value)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { val today = LocalDate.now(); AssistChip({ onChange(today.toString()) }, label = { Text("Hoy") }); AssistChip({ onChange(today.plusDays(1).toString()) }, label = { Text("Mañana") }); if (allowNone && value != null) AssistChip({ onChange(null) }, label = { Text("Quitar") }) }
    }
}

@Composable
private fun TimeField(label: String, value: String?, allowNone: Boolean, onChange: (String?) -> Unit) {
    val context = LocalContext.current; val current = value?.let { runCatching { LocalTime.parse(it) }.getOrNull() } ?: LocalTime.now()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        OutlinedButton(onClick = { TimePickerDialog(context, { _, h, m -> onChange(LocalTime.of(h, m).format(DateTimeFormatter.ofPattern("HH:mm"))) }, current.hour, current.minute, true).show() }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Schedule, null); Spacer(Modifier.width(8.dp)); Text("Seleccionar hora") }
        if (value != null) Text("Elegida: $value", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { AssistChip({ onChange(LocalTime.now().withSecond(0).withNano(0).format(DateTimeFormatter.ofPattern("HH:mm"))) }, label = { Text("Ahora") }); AssistChip({ onChange("09:00") }, label = { Text("09:00") }); AssistChip({ onChange("18:00") }, label = { Text("18:00") }); if (allowNone && value != null) AssistChip({ onChange(null) }, label = { Text("Quitar") }) }
    }
}

@Composable
private fun RepeatEditor(value: RepeatRule, onChange: (RepeatRule) -> Unit) {
    var menu by remember { mutableStateOf(false) }; var interval by remember(value.interval) { mutableStateOf(value.interval.toString()) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("Repetición", style = MaterialTheme.typography.labelMedium); Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box { OutlinedButton({ menu = true }) { Text(repeatLabel(value.unit)) }; DropdownMenu(menu, { menu = false }) { RepeatUnit.entries.forEach { unit -> DropdownMenuItem({ Text(repeatLabel(unit)) }, { menu = false; onChange(value.copy(unit = unit)) }) } } }; if (value.unit != RepeatUnit.NONE) OutlinedTextField(interval, { s -> interval = s.filter(Char::isDigit).take(4); onChange(value.copy(interval = interval.toIntOrNull()?.coerceAtLeast(1) ?: 1)) }, label = { Text("Cada") }, modifier = Modifier.width(100.dp), singleLine = true) } }
}
private fun repeatLabel(unit: RepeatUnit) = when (unit) { RepeatUnit.NONE -> "No repetir"; RepeatUnit.MINUTES -> "Minutos"; RepeatUnit.HOURS -> "Horas"; RepeatUnit.DAYS -> "Días"; RepeatUnit.WEEKS -> "Semanas"; RepeatUnit.MONTHS -> "Meses"; RepeatUnit.YEARS -> "Años" }

@Composable
private fun AlertsEditor(value: List<Int>, title: String, onChange: (List<Int>) -> Unit) {
    var custom by remember { mutableStateOf("") }; val presets = listOf(0 to "A la hora", 5 to "5 min", 15 to "15 min", 30 to "30 min", 60 to "1 h", 1440 to "1 día")
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) { Text(title, style = MaterialTheme.typography.labelMedium); presets.chunked(3).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { row.forEach { (min, label) -> FilterChip(min in value, { onChange(if (min in value) value - min else (value + min).distinct().sorted()) }, label = { Text(label) }) } } }; if (value.isNotEmpty()) value.chunked(3).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { row.forEach { min -> InputChip(true, { onChange(value - min) }, label = { Text(alertLabel(min)) }, trailingIcon = { Icon(Icons.Default.Close, "Quitar") }) } } }; Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedTextField(custom, { custom = it.filter(Char::isDigit).take(6) }, label = { Text("Minutos antes") }, modifier = Modifier.weight(1f), singleLine = true); Button({ custom.toIntOrNull()?.coerceAtLeast(0)?.let { onChange((value + it).distinct().sorted()); custom = "" } }, enabled = custom.toIntOrNull() != null) { Text("Añadir") } }; Text("Puedes añadir todos los avisos que necesites.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
}
private fun alertLabel(min: Int) = when (min) { 0 -> "A la hora"; 60 -> "1 h antes"; 1440 -> "1 día antes"; else -> "$min min antes" }

@Composable private fun SectionTitle(text: String) { Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
@Composable private fun EmptyCard(text: String) { Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)) { Text(text, Modifier.fillMaxWidth().padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) } }
private fun prettyDate(raw: String) = runCatching { LocalDate.parse(raw).format(DateTimeFormatter.ofPattern("d MMM", Locale("es", "CO"))) }.getOrDefault(raw)
private fun prettyDateLong(raw: String) = runCatching { LocalDate.parse(raw).format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale("es", "CO"))).replaceFirstChar { it.uppercase() } }.getOrDefault(raw)
private fun dateTitle(date: LocalDate) = date.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale("es", "CO"))).replaceFirstChar { it.uppercase() }
