# Mi Día Android — v0.4.0

Aplicación Android personal para tareas, eventos, recordatorios y cumpleaños.

## Cambios v0.4
- Tema de color aplicado de forma consistente a controles, selecciones, calendario, estadísticas y navegación.
- Opción de interfaz monocromática.
- Modo oscuro AMOLED con fondo negro puro.
- Ajustes de notificaciones por tipo y vibración.
- Iconos distintos en notificaciones para tarea, evento, recordatorio y cumpleaños.
- Cumpleaños como tipo propio, con selector de contacto del teléfono y repetición anual.
- Inicio organizado con tres botones: Tareas, Eventos y Avisos.
- Filtro de tareas concentrado en un botón “Filtrar”, por prioridad y categoría.
- Subtareas completas: se pueden crear al editar/crear la tarea o desde la tarjeta de la tarea; incluyen notas, categoría, prioridad, fechas, hora, duración, repetición y avisos.
- Los botones de fecha/hora dicen siempre “Seleccionar fecha” y “Seleccionar hora”; la selección aparece como texto de apoyo después de elegir.
- Conserva el mismo applicationId `com.midia.app` para actualizar instalaciones anteriores.
