# Mi Día Android v0.5.0

Rediseño principal:
- Inicio centrado en calendario Día / Semana / Mes.
- Bienvenida con nombre local y reloj.
- Accesos Sin fecha y hora y Completados.
- Agenda unificada y ordenada por fecha/hora.
- Filtro global por tipo, prioridad y categoría.
- Pantalla independiente de Estadísticas con tiempo libre, progreso y conteos.
- Mantiene tareas, eventos, recordatorios, cumpleaños, subtareas, temas y notificaciones.
