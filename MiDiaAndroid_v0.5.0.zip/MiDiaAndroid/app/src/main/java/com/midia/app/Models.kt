package com.midia.app

import java.time.LocalDate
import java.time.LocalTime
import java.time.temporal.ChronoUnit
import java.util.UUID

enum class RepeatUnit { NONE, MINUTES, HOURS, DAYS, WEEKS, MONTHS, YEARS }
enum class Priority { LOW, MEDIUM, HIGH, URGENT }
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class AccentColor { GREEN, BLUE, PURPLE, ORANGE, ROSE, MONOCHROME }

data class RepeatRule(
    val unit: RepeatUnit = RepeatUnit.NONE,
    val interval: Int = 1
)

data class SubTask(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val notes: String = "",
    val category: String = "",
    val priority: Priority = Priority.MEDIUM,
    val doDate: String? = null,
    val dueDate: String? = null,
    val startTime: String? = null,
    val durationMinutes: Int? = null,
    val completed: Boolean = false,
    val repeat: RepeatRule = RepeatRule(),
    val alerts: List<Int> = emptyList()
)

data class TaskItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val notes: String = "",
    val category: String = "",
    val priority: Priority = Priority.MEDIUM,
    val subtasks: List<SubTask> = emptyList(),
    val doDate: String? = null,
    val dueDate: String? = null,
    val startTime: String? = null,
    val durationMinutes: Int? = null,
    val completed: Boolean = false,
    val repeat: RepeatRule = RepeatRule(),
    val alerts: List<Int> = emptyList()
)

data class EventItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val startTime: String,
    val endTime: String,
    val notes: String = "",
    val location: String = "",
    val category: String = "",
    val done: Boolean = false,
    val repeat: RepeatRule = RepeatRule(),
    val alerts: List<Int> = emptyList()
)

data class ReminderItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val time: String,
    val notes: String = "",
    val category: String = "",
    val done: Boolean = false,
    val repeat: RepeatRule = RepeatRule(),
    val repeatUntilDone: Boolean = false,
    val snoozedUntilMillis: Long? = null,
    val alerts: List<Int> = emptyList()
)

data class BirthdayItem(
    val id: String = UUID.randomUUID().toString(),
    val contactName: String,
    val contactUri: String? = null,
    val birthDate: String,
    val time: String = "09:00",
    val notes: String = "",
    val alerts: List<Int> = listOf(0, 1440)
)

// Legacy de v0.2; se conserva para no romper datos ya guardados.
data class FreeSlotOverride(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val startMinutes: Int,
    val endMinutes: Int
)

data class AppSettings(
    val profileName: String = "Samuel",
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accentColor: AccentColor = AccentColor.GREEN,
    val notificationsEnabled: Boolean = true,
    val taskNotifications: Boolean = true,
    val eventNotifications: Boolean = true,
    val reminderNotifications: Boolean = true,
    val birthdayNotifications: Boolean = true,
    val notificationVibration: Boolean = true
)

data class AppState(
    val tasks: List<TaskItem> = emptyList(),
    val events: List<EventItem> = emptyList(),
    val reminders: List<ReminderItem> = emptyList(),
    val birthdays: List<BirthdayItem> = emptyList(),
    val freeSlotOverrides: List<FreeSlotOverride> = emptyList(),
    val settings: AppSettings = AppSettings()
)

data class TimeSlot(val startMinutes: Int, val endMinutes: Int)

data class DayTimeStats(
    val freeMinutes: Int,
    val busyMinutes: Int,
    val taskMinutes: Int,
    val eventMinutes: Int,
    val reminderCount: Int
)

fun LocalTime.toMinutes(): Int = hour * 60 + minute

fun occursOn(baseDate: String, rule: RepeatRule, target: LocalDate): Boolean {
    val base = runCatching { LocalDate.parse(baseDate) }.getOrNull() ?: return false
    if (target.isBefore(base)) return false
    if (target == base) return true
    val n = rule.interval.coerceAtLeast(1)
    return when (rule.unit) {
        RepeatUnit.NONE -> false
        RepeatUnit.MINUTES, RepeatUnit.HOURS -> true
        RepeatUnit.DAYS -> ChronoUnit.DAYS.between(base, target) % n == 0L
        RepeatUnit.WEEKS -> ChronoUnit.WEEKS.between(base, target) % n == 0L && target.dayOfWeek == base.dayOfWeek
        RepeatUnit.MONTHS -> {
            val months = ChronoUnit.MONTHS.between(base.withDayOfMonth(1), target.withDayOfMonth(1))
            months % n == 0L && target.dayOfMonth == base.dayOfMonth.coerceAtMost(target.lengthOfMonth())
        }
        RepeatUnit.YEARS -> {
            val years = ChronoUnit.YEARS.between(base, target)
            years % n == 0L && target.month == base.month && target.dayOfMonth == base.dayOfMonth.coerceAtMost(target.lengthOfMonth())
        }
    }
}

fun birthdayOccursOn(item: BirthdayItem, target: LocalDate): Boolean {
    val birth = runCatching { LocalDate.parse(item.birthDate) }.getOrNull() ?: return false
    return birth.month == target.month && birth.dayOfMonth.coerceAtMost(target.lengthOfMonth()) == target.dayOfMonth
}

fun nextOccurrence(fromMillis: Long, rule: RepeatRule, repeatUntilDone: Boolean = false): Long? {
    val base = java.time.Instant.ofEpochMilli(fromMillis).atZone(java.time.ZoneId.systemDefault())
    val n = rule.interval.coerceAtLeast(1).toLong()
    val next = when (rule.unit) {
        RepeatUnit.NONE -> if (repeatUntilDone) base.plusMinutes(15) else return null
        RepeatUnit.MINUTES -> base.plusMinutes(n)
        RepeatUnit.HOURS -> base.plusHours(n)
        RepeatUnit.DAYS -> base.plusDays(n)
        RepeatUnit.WEEKS -> base.plusWeeks(n)
        RepeatUnit.MONTHS -> base.plusMonths(n)
        RepeatUnit.YEARS -> base.plusYears(n)
    }
    return next.toInstant().toEpochMilli()
}

fun dayTimeStats(state: AppState, date: LocalDate): DayTimeStats {
    val eventSlots = state.events.filter { !it.done && occursOn(it.date, it.repeat, date) }.mapNotNull { e ->
        val start = runCatching { LocalTime.parse(e.startTime).toMinutes() }.getOrNull() ?: return@mapNotNull null
        val end = runCatching { LocalTime.parse(e.endTime).toMinutes() }.getOrNull() ?: (start + 60)
        TimeSlot(start.coerceIn(0, 1439), maxOf(end, start + 5).coerceIn(1, 1440))
    }
    val taskSlots = state.tasks.filter {
        !it.completed && it.doDate != null && occursOn(it.doDate, it.repeat, date) && it.startTime != null
    }.mapNotNull { t ->
        val start = runCatching { LocalTime.parse(t.startTime).toMinutes() }.getOrNull() ?: return@mapNotNull null
        TimeSlot(start.coerceIn(0, 1439), (start + (t.durationMinutes ?: 30).coerceAtLeast(5)).coerceAtMost(1440))
    }

    fun mergedMinutes(slots: List<TimeSlot>): Int {
        if (slots.isEmpty()) return 0
        val sorted = slots.sortedBy { it.startMinutes }
        var total = 0
        var s = sorted.first().startMinutes
        var e = sorted.first().endMinutes
        for (slot in sorted.drop(1)) {
            if (slot.startMinutes <= e) e = maxOf(e, slot.endMinutes)
            else { total += e - s; s = slot.startMinutes; e = slot.endMinutes }
        }
        return (total + e - s).coerceIn(0, 1440)
    }

    val busy = mergedMinutes(eventSlots + taskSlots)
    val reminders = state.reminders.count { !it.done && occursOn(it.date, it.repeat, date) } + state.birthdays.count { birthdayOccursOn(it, date) }
    return DayTimeStats(
        freeMinutes = (1440 - busy).coerceAtLeast(0),
        busyMinutes = busy,
        taskMinutes = mergedMinutes(taskSlots),
        eventMinutes = mergedMinutes(eventSlots),
        reminderCount = reminders
    )
}

fun taskDateTime(task: TaskItem) = task.doDate?.let { d -> task.startTime?.let { t -> runCatching { java.time.LocalDateTime.of(LocalDate.parse(d), LocalTime.parse(t)) }.getOrNull() } }
fun eventDateTime(event: EventItem) = runCatching { java.time.LocalDateTime.of(LocalDate.parse(event.date), LocalTime.parse(event.startTime)) }.getOrNull()
fun reminderDateTime(reminder: ReminderItem) = runCatching { java.time.LocalDateTime.of(LocalDate.parse(reminder.date), LocalTime.parse(reminder.time)) }.getOrNull()

fun formatDuration(minutes: Int): String {
    val safe = minutes.coerceAtLeast(0)
    val h = safe / 60
    val m = safe % 60
    return when {
        h == 0 -> "$m min"
        m == 0 -> "$h h"
        else -> "$h h $m min"
    }
}
