package com.midia.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

class AppStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("midia_state", Context.MODE_PRIVATE)
    var state by mutableStateOf(load())
        private set

    fun update(transform: (AppState) -> AppState) {
        state = transform(state)
        save(state)
        NotificationScheduler.rescheduleAll(context, state)
    }

    fun addTask(item: TaskItem) = update { it.copy(tasks = it.tasks + item) }
    fun addEvent(item: EventItem) = update { it.copy(events = it.events + item) }
    fun addReminder(item: ReminderItem) = update { it.copy(reminders = it.reminders + item) }
    fun addBirthday(item: BirthdayItem) = update { it.copy(birthdays = it.birthdays + item) }

    fun replaceTask(item: TaskItem) = update { s -> s.copy(tasks = s.tasks.map { if (it.id == item.id) item else it }) }
    fun replaceEvent(item: EventItem) = update { s -> s.copy(events = s.events.map { if (it.id == item.id) item else it }) }
    fun replaceReminder(item: ReminderItem) = update { s -> s.copy(reminders = s.reminders.map { if (it.id == item.id) item else it }) }
    fun replaceBirthday(item: BirthdayItem) = update { s -> s.copy(birthdays = s.birthdays.map { if (it.id == item.id) item else it }) }

    fun deleteTask(id: String) = update { it.copy(tasks = it.tasks.filterNot { x -> x.id == id }) }
    fun deleteEvent(id: String) = update { it.copy(events = it.events.filterNot { x -> x.id == id }) }
    fun deleteReminder(id: String) = update { it.copy(reminders = it.reminders.filterNot { x -> x.id == id }) }
    fun deleteBirthday(id: String) = update { it.copy(birthdays = it.birthdays.filterNot { x -> x.id == id }) }

    fun setProfileName(name: String) = update { it.copy(settings = it.settings.copy(profileName = name.trim().ifBlank { "Usuario" })) }
    fun setThemeMode(mode: ThemeMode) = update { it.copy(settings = it.settings.copy(themeMode = mode)) }
    fun setAccentColor(color: AccentColor) = update { it.copy(settings = it.settings.copy(accentColor = color)) }
    fun setNotificationsEnabled(v: Boolean) = update { it.copy(settings = it.settings.copy(notificationsEnabled = v)) }
    fun setTaskNotifications(v: Boolean) = update { it.copy(settings = it.settings.copy(taskNotifications = v)) }
    fun setEventNotifications(v: Boolean) = update { it.copy(settings = it.settings.copy(eventNotifications = v)) }
    fun setReminderNotifications(v: Boolean) = update { it.copy(settings = it.settings.copy(reminderNotifications = v)) }
    fun setBirthdayNotifications(v: Boolean) = update { it.copy(settings = it.settings.copy(birthdayNotifications = v)) }
    fun setNotificationVibration(v: Boolean) = update { it.copy(settings = it.settings.copy(notificationVibration = v)) }

    fun clearAll() = update { current -> AppState(settings = current.settings) }

    private fun save(s: AppState) {
        val root = JSONObject()
        root.put("tasks", JSONArray().apply { s.tasks.forEach { put(taskToJson(it)) } })
        root.put("events", JSONArray().apply { s.events.forEach { put(eventToJson(it)) } })
        root.put("reminders", JSONArray().apply { s.reminders.forEach { put(reminderToJson(it)) } })
        root.put("birthdays", JSONArray().apply { s.birthdays.forEach { put(birthdayToJson(it)) } })
        root.put("freeSlotOverrides", JSONArray().apply { s.freeSlotOverrides.forEach { put(freeSlotToJson(it)) } })
        root.put("settings", settingsToJson(s.settings))
        prefs.edit().putString("state", root.toString()).apply()
    }

    private fun load(): AppState {
        val raw = prefs.getString("state", null) ?: return demoState()
        return runCatching {
            val root = JSONObject(raw)
            AppState(
                tasks = root.optJSONArray("tasks").mapObjects(::taskFromJson),
                events = root.optJSONArray("events").mapObjects(::eventFromJson),
                reminders = root.optJSONArray("reminders").mapObjects(::reminderFromJson),
                birthdays = root.optJSONArray("birthdays").mapObjects(::birthdayFromJson),
                freeSlotOverrides = root.optJSONArray("freeSlotOverrides").mapObjects(::freeSlotFromJson),
                settings = settingsFromJson(root.optJSONObject("settings"))
            )
        }.getOrElse { AppState() }
    }

    private fun demoState(): AppState {
        val today = java.time.LocalDate.now().toString()
        val yesterday = java.time.LocalDate.now().minusDays(1).toString()
        return AppState(
            tasks = listOf(
                TaskItem(
                    title = "Terminar presentación", category = "Universidad", priority = Priority.HIGH,
                    doDate = today, dueDate = today, startTime = "10:30", durationMinutes = 60,
                    alerts = listOf(15, 60),
                    subtasks = listOf(SubTask(title = "Revisar diapositivas"), SubTask(title = "Exportar PDF"))
                ),
                TaskItem(title = "Organizar archivos pendientes", category = "Personal", priority = Priority.MEDIUM, doDate = yesterday),
                TaskItem(title = "Comprar algo para la casa", category = "Personal", priority = Priority.LOW, doDate = null)
            ),
            events = listOf(
                EventItem(title = "Clase", date = today, startTime = "08:00", endTime = "10:00", location = "Universidad", category = "Universidad", alerts = listOf(15)),
                EventItem(title = "Almuerzo", date = today, startTime = "13:00", endTime = "14:00", category = "Personal")
            ),
            reminders = listOf(ReminderItem(title = "Revisar pendientes", date = today, time = "19:00", category = "Personal", repeatUntilDone = true, alerts = listOf(30)))
        )
    }
}

private inline fun <reified T> JSONArray?.mapObjects(parser: (JSONObject) -> T): List<T> {
    if (this == null) return emptyList()
    return buildList { for (i in 0 until length()) add(parser(getJSONObject(i))) }
}

private fun repeatToJson(r: RepeatRule) = JSONObject().put("unit", r.unit.name).put("interval", r.interval)
private fun repeatFromJson(o: JSONObject?) = RepeatRule(
    unit = runCatching { RepeatUnit.valueOf(o?.optString("unit") ?: "NONE") }.getOrDefault(RepeatUnit.NONE),
    interval = (o?.optInt("interval", 1) ?: 1).coerceAtLeast(1)
)
private fun alertsToJson(list: List<Int>) = JSONArray().apply { list.forEach { put(it) } }
private fun alertsFromJson(a: JSONArray?): List<Int> = if (a == null) emptyList() else buildList { for (i in 0 until a.length()) add(a.optInt(i)) }

private fun subtasksToJson(list: List<SubTask>) = JSONArray().apply {
    list.forEach { s -> put(JSONObject().apply {
        put("id", s.id); put("title", s.title); put("notes", s.notes); put("category", s.category); put("priority", s.priority.name)
        put("doDate", s.doDate); put("dueDate", s.dueDate); put("startTime", s.startTime); put("duration", s.durationMinutes)
        put("completed", s.completed); put("repeat", repeatToJson(s.repeat)); put("alerts", alertsToJson(s.alerts))
    }) }
}
private fun subtasksFromJson(a: JSONArray?): List<SubTask> = if (a == null) emptyList() else buildList {
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        val title = o.optString("title").trim()
        if (title.isNotBlank()) add(SubTask(
            id = o.optString("id").ifBlank { java.util.UUID.randomUUID().toString() }, title = title,
            notes = o.optString("notes"), category = o.optString("category"),
            priority = runCatching { Priority.valueOf(o.optString("priority", "MEDIUM")) }.getOrDefault(Priority.MEDIUM),
            doDate = o.optNullableString("doDate"), dueDate = o.optNullableString("dueDate"), startTime = o.optNullableString("startTime"),
            durationMinutes = if (o.isNull("duration")) null else o.optInt("duration"), completed = o.optBoolean("completed"),
            repeat = repeatFromJson(o.optJSONObject("repeat")), alerts = alertsFromJson(o.optJSONArray("alerts"))
        ))
    }
}

private fun taskToJson(t: TaskItem) = JSONObject().apply {
    put("id", t.id); put("title", t.title); put("notes", t.notes); put("category", t.category); put("priority", t.priority.name)
    put("subtasks", subtasksToJson(t.subtasks)); put("doDate", t.doDate); put("dueDate", t.dueDate); put("startTime", t.startTime); put("duration", t.durationMinutes)
    put("completed", t.completed); put("repeat", repeatToJson(t.repeat)); put("alerts", alertsToJson(t.alerts))
}
private fun taskFromJson(o: JSONObject) = TaskItem(
    id = o.optString("id").ifBlank { java.util.UUID.randomUUID().toString() }, title = o.optString("title"), notes = o.optString("notes"), category = o.optString("category"),
    priority = runCatching { Priority.valueOf(o.optString("priority", "MEDIUM")) }.getOrDefault(Priority.MEDIUM), subtasks = subtasksFromJson(o.optJSONArray("subtasks")),
    doDate = o.optNullableString("doDate"), dueDate = o.optNullableString("dueDate"), startTime = o.optNullableString("startTime"),
    durationMinutes = if (o.isNull("duration")) null else o.optInt("duration"), completed = o.optBoolean("completed"),
    repeat = repeatFromJson(o.optJSONObject("repeat")), alerts = alertsFromJson(o.optJSONArray("alerts"))
)

private fun eventToJson(e: EventItem) = JSONObject().apply {
    put("id", e.id); put("title", e.title); put("date", e.date); put("startTime", e.startTime); put("endTime", e.endTime)
    put("notes", e.notes); put("location", e.location); put("category", e.category); put("done", e.done); put("repeat", repeatToJson(e.repeat)); put("alerts", alertsToJson(e.alerts))
}
private fun eventFromJson(o: JSONObject) = EventItem(
    id = o.optString("id").ifBlank { java.util.UUID.randomUUID().toString() }, title = o.optString("title"), date = o.optString("date"), startTime = o.optString("startTime"), endTime = o.optString("endTime"),
    notes = o.optString("notes"), location = o.optString("location"), category = o.optString("category"), done = o.optBoolean("done"),
    repeat = repeatFromJson(o.optJSONObject("repeat")), alerts = alertsFromJson(o.optJSONArray("alerts"))
)

private fun reminderToJson(r: ReminderItem) = JSONObject().apply {
    put("id", r.id); put("title", r.title); put("date", r.date); put("time", r.time); put("notes", r.notes); put("category", r.category); put("done", r.done)
    put("repeat", repeatToJson(r.repeat)); put("repeatUntilDone", r.repeatUntilDone); put("snoozedUntil", r.snoozedUntilMillis); put("alerts", alertsToJson(r.alerts))
}
private fun reminderFromJson(o: JSONObject) = ReminderItem(
    id = o.optString("id").ifBlank { java.util.UUID.randomUUID().toString() }, title = o.optString("title"), date = o.optString("date"), time = o.optString("time"), notes = o.optString("notes"), category = o.optString("category"),
    done = o.optBoolean("done"), repeat = repeatFromJson(o.optJSONObject("repeat")), repeatUntilDone = o.optBoolean("repeatUntilDone"),
    snoozedUntilMillis = if (o.isNull("snoozedUntil")) null else o.optLong("snoozedUntil"), alerts = alertsFromJson(o.optJSONArray("alerts"))
)

private fun birthdayToJson(b: BirthdayItem) = JSONObject().apply {
    put("id", b.id); put("contactName", b.contactName); put("contactUri", b.contactUri); put("birthDate", b.birthDate); put("time", b.time); put("notes", b.notes); put("alerts", alertsToJson(b.alerts))
}
private fun birthdayFromJson(o: JSONObject) = BirthdayItem(
    id = o.optString("id").ifBlank { java.util.UUID.randomUUID().toString() }, contactName = o.optString("contactName"), contactUri = o.optNullableString("contactUri"),
    birthDate = o.optString("birthDate"), time = o.optString("time", "09:00"), notes = o.optString("notes"), alerts = alertsFromJson(o.optJSONArray("alerts")).ifEmpty { listOf(0, 1440) }
)

private fun settingsToJson(s: AppSettings) = JSONObject().apply {
    put("profileName", s.profileName); put("themeMode", s.themeMode.name); put("accentColor", s.accentColor.name); put("notificationsEnabled", s.notificationsEnabled)
    put("taskNotifications", s.taskNotifications); put("eventNotifications", s.eventNotifications); put("reminderNotifications", s.reminderNotifications)
    put("birthdayNotifications", s.birthdayNotifications); put("notificationVibration", s.notificationVibration)
}
private fun settingsFromJson(o: JSONObject?) = AppSettings(
    profileName = o?.optString("profileName", "Samuel")?.ifBlank { "Usuario" } ?: "Samuel",
    themeMode = runCatching { ThemeMode.valueOf(o?.optString("themeMode") ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM),
    accentColor = runCatching { AccentColor.valueOf(o?.optString("accentColor") ?: "GREEN") }.getOrDefault(AccentColor.GREEN),
    notificationsEnabled = o?.optBoolean("notificationsEnabled", true) ?: true,
    taskNotifications = o?.optBoolean("taskNotifications", true) ?: true,
    eventNotifications = o?.optBoolean("eventNotifications", true) ?: true,
    reminderNotifications = o?.optBoolean("reminderNotifications", true) ?: true,
    birthdayNotifications = o?.optBoolean("birthdayNotifications", true) ?: true,
    notificationVibration = o?.optBoolean("notificationVibration", true) ?: true
)

private fun freeSlotToJson(slot: FreeSlotOverride) = JSONObject().apply {
    put("id", slot.id); put("date", slot.date); put("startMinutes", slot.startMinutes); put("endMinutes", slot.endMinutes)
}
private fun freeSlotFromJson(o: JSONObject) = FreeSlotOverride(
    id = o.optString("id"), date = o.optString("date"), startMinutes = o.optInt("startMinutes"), endMinutes = o.optInt("endMinutes")
)

private fun JSONObject.optNullableString(key: String): String? = if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
