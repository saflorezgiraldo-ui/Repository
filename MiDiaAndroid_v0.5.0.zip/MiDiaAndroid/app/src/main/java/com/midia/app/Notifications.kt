package com.midia.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.absoluteValue

enum class NotificationKind { TASK, EVENT, REMINDER, BIRTHDAY, TEST }

object NotificationScheduler {
    private const val CHANNEL_VIBRATE = "midia_alerts_vibrate"
    private const val CHANNEL_SILENT = "midia_alerts_silent"
    private const val PREFS = "midia_alarm_codes"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_VIBRATE, "Mi Día · con vibración", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Avisos de tareas, eventos, recordatorios y cumpleaños"
                enableVibration(true)
            })
            manager.createNotificationChannel(NotificationChannel(CHANNEL_SILENT, "Mi Día · sin vibración", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Avisos de Mi Día sin vibración"
                enableVibration(false)
                vibrationPattern = longArrayOf(0)
            })
        }
    }

    fun showTest(context: Context, vibration: Boolean = true) {
        createChannel(context)
        showNotification(context, "Mi Día", "Las notificaciones están funcionando.", "test".hashCode().absoluteValue, NotificationKind.TEST, vibration)
    }

    fun canExact(context: Context): Boolean {
        val alarm = context.getSystemService(AlarmManager::class.java)
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarm.canScheduleExactAlarms()
    }

    fun exactAlarmSettingsIntent(context: Context): Intent? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || canExact(context)) return null
        return Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
            data = android.net.Uri.parse("package:${context.packageName}")
        }
    }

    fun rescheduleAll(context: Context, state: AppState) {
        createChannel(context)
        cancelPreviouslyScheduled(context)
        if (!state.settings.notificationsEnabled) return
        val codes = mutableSetOf<Int>()
        val now = System.currentTimeMillis()
        val vibrate = state.settings.notificationVibration

        if (state.settings.taskNotifications) {
            state.tasks.filterNot { it.completed }.forEach { task ->
                val base = taskDateTime(task)?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()
                if (base != null) task.alerts.forEachIndexed { idx, offset ->
                    val trigger = base - offset * 60_000L
                    if (trigger > now) codes += schedule(context, "task:${task.id}:$idx", "Tarea: ${task.title}", task.dueDate?.let { "Fecha límite: $it" } ?: "Tienes una tarea pendiente", trigger, task.repeat, false, NotificationKind.TASK, vibrate)
                }
                task.subtasks.filterNot { it.completed }.forEach { sub ->
                    val subBase = sub.doDate?.let { d -> sub.startTime?.let { t -> runCatching { LocalDateTime.of(LocalDate.parse(d), LocalTime.parse(t)) }.getOrNull() } }
                        ?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()
                    if (subBase != null) sub.alerts.forEachIndexed { idx, offset ->
                        val trigger = subBase - offset * 60_000L
                        if (trigger > now) codes += schedule(context, "subtask:${task.id}:${sub.id}:$idx", "Subtarea: ${sub.title}", "De ${task.title}", trigger, sub.repeat, false, NotificationKind.TASK, vibrate)
                    }
                }
            }
        }

        if (state.settings.eventNotifications) {
            state.events.filterNot { it.done }.forEach { event ->
                val base = eventDateTime(event)?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli() ?: return@forEach
                event.alerts.forEachIndexed { idx, offset ->
                    val trigger = base - offset * 60_000L
                    if (trigger > now) codes += schedule(context, "event:${event.id}:$idx", "Evento: ${event.title}", "Empieza a las ${event.startTime}", trigger, event.repeat, false, NotificationKind.EVENT, vibrate)
                }
            }
        }

        if (state.settings.reminderNotifications) {
            state.reminders.filterNot { it.done }.forEach { reminder ->
                val normal = reminderDateTime(reminder)?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli() ?: return@forEach
                if (reminder.snoozedUntilMillis != null && reminder.snoozedUntilMillis > now) {
                    codes += schedule(context, "reminder:${reminder.id}:snooze", reminder.title, reminder.notes.ifBlank { "Recordatorio" }, reminder.snoozedUntilMillis, reminder.repeat, reminder.repeatUntilDone, NotificationKind.REMINDER, vibrate)
                } else {
                    val offsets = (reminder.alerts + 0).distinct().sortedDescending()
                    offsets.forEachIndexed { idx, offset ->
                        val trigger = normal - offset * 60_000L
                        if (trigger > now) codes += schedule(
                            context, "reminder:${reminder.id}:$idx:$offset",
                            if (offset == 0) reminder.title else "Próximo recordatorio: ${reminder.title}",
                            reminder.notes.ifBlank { if (offset == 0) "Recordatorio" else "Faltan $offset min" },
                            trigger, reminder.repeat, reminder.repeatUntilDone && offset == 0, NotificationKind.REMINDER, vibrate
                        )
                    }
                }
            }
        }

        if (state.settings.birthdayNotifications) {
            state.birthdays.forEach { birthday ->
                val birth = runCatching { LocalDate.parse(birthday.birthDate) }.getOrNull() ?: return@forEach
                val time = runCatching { LocalTime.parse(birthday.time) }.getOrDefault(LocalTime.of(9, 0))
                val today = LocalDate.now()
                var nextDate = LocalDate.of(today.year, birth.month, birth.dayOfMonth.coerceAtMost(LocalDate.of(today.year, birth.month, 1).lengthOfMonth()))
                if (LocalDateTime.of(nextDate, time).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() <= now) {
                    val y = today.year + 1
                    nextDate = LocalDate.of(y, birth.month, birth.dayOfMonth.coerceAtMost(LocalDate.of(y, birth.month, 1).lengthOfMonth()))
                }
                val base = LocalDateTime.of(nextDate, time).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                birthday.alerts.distinct().forEachIndexed { idx, offset ->
                    val trigger = base - offset * 60_000L
                    if (trigger > now) codes += schedule(context, "birthday:${birthday.id}:$idx", "Cumpleaños: ${birthday.contactName}", birthday.notes.ifBlank { "Hoy cumple años ${birthday.contactName}" }, trigger, RepeatRule(RepeatUnit.YEARS, 1), false, NotificationKind.BIRTHDAY, vibrate)
                }
            }
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet("codes", codes.map(Int::toString).toSet()).apply()
    }

    private fun schedule(
        context: Context,
        key: String,
        title: String,
        body: String,
        triggerMillis: Long,
        rule: RepeatRule,
        repeatUntilDone: Boolean,
        kind: NotificationKind,
        vibration: Boolean,
        requestCodeOverride: Int? = null
    ): Int {
        val requestCode = requestCodeOverride ?: key.hashCode().absoluteValue
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra("title", title); putExtra("body", body); putExtra("code", requestCode)
            putExtra("repeatUnit", rule.unit.name); putExtra("repeatInterval", rule.interval); putExtra("repeatUntilDone", repeatUntilDone)
            putExtra("kind", kind.name); putExtra("vibration", vibration)
        }
        val pi = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(AlarmManager::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
            else alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
        } catch (_: SecurityException) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
        }
        return requestCode
    }

    private fun cancelPreviouslyScheduled(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val codes = prefs.getStringSet("codes", emptySet()).orEmpty().mapNotNull { it.toIntOrNull() }
        val alarm = context.getSystemService(AlarmManager::class.java)
        codes.forEach { code ->
            val pi = PendingIntent.getBroadcast(context, code, Intent(context, NotificationReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (pi != null) alarm.cancel(pi)
        }
        prefs.edit().remove("codes").apply()
    }

    fun scheduleNextFromReceiver(context: Context, originalIntent: Intent) {
        val unit = runCatching { RepeatUnit.valueOf(originalIntent.getStringExtra("repeatUnit") ?: "NONE") }.getOrDefault(RepeatUnit.NONE)
        val interval = originalIntent.getIntExtra("repeatInterval", 1).coerceAtLeast(1)
        val repeatUntilDone = originalIntent.getBooleanExtra("repeatUntilDone", false)
        val next = nextOccurrence(System.currentTimeMillis(), RepeatRule(unit, interval), repeatUntilDone) ?: return
        val kind = runCatching { NotificationKind.valueOf(originalIntent.getStringExtra("kind") ?: "REMINDER") }.getOrDefault(NotificationKind.REMINDER)
        schedule(context, "receiver:${originalIntent.getIntExtra("code", 0)}", originalIntent.getStringExtra("title") ?: "Mi Día", originalIntent.getStringExtra("body") ?: "Recordatorio", next, RepeatRule(unit, interval), repeatUntilDone, kind, originalIntent.getBooleanExtra("vibration", true), originalIntent.getIntExtra("code", 0))
    }

    private fun iconFor(kind: NotificationKind): Int = when (kind) {
        NotificationKind.TASK -> R.drawable.ic_notification_task
        NotificationKind.EVENT -> R.drawable.ic_notification_event
        NotificationKind.REMINDER -> R.drawable.ic_notification_reminder
        NotificationKind.BIRTHDAY -> R.drawable.ic_notification_birthday
        NotificationKind.TEST -> R.drawable.ic_notification
    }

    private fun showNotification(context: Context, title: String, body: String, id: Int, kind: NotificationKind, vibration: Boolean) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val openApp = PendingIntent.getActivity(context, id, Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, if (vibration) CHANNEL_VIBRATE else CHANNEL_SILENT)
            .setSmallIcon(iconFor(kind)).setContentTitle(title).setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(openApp).build()
        NotificationManagerCompat.from(context).notify(id, notification)
    }

    fun deliver(context: Context, intent: Intent) {
        createChannel(context)
        val kind = runCatching { NotificationKind.valueOf(intent.getStringExtra("kind") ?: "REMINDER") }.getOrDefault(NotificationKind.REMINDER)
        showNotification(context, intent.getStringExtra("title") ?: "Mi Día", intent.getStringExtra("body") ?: "Recordatorio", intent.getIntExtra("code", System.currentTimeMillis().toInt().absoluteValue), kind, intent.getBooleanExtra("vibration", true))
        scheduleNextFromReceiver(context, intent)
    }
}

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { NotificationScheduler.deliver(context, intent) }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val store = AppStore(context.applicationContext)
            NotificationScheduler.rescheduleAll(context, store.state)
        }
    }
}
